# MovieStream - PHP Movie Catalog (Enhanced v2.0)

A complete Netflix-inspired movie catalog website with advanced features including categories browser, favorites system, and advanced search. Built with PHP, MySQL, HTML, CSS, and JavaScript for school projects.

## 📋 Features

### Core Features
- **Movie Catalog Display** - Browse movies organized by category in horizontal rows
- **Category Browser** - Dedicated page to explore all genres (NEW!)
- **Favorites System** - Save and manage your favorite movies (NEW!)
- **Advanced Search** - Multi-filter search with sorting options (NEW!)
- **Movie Details** - Full information page with similar movies
- **User Authentication** - Simple login/logout system
- **Responsive Design** - Works on desktop, tablet, and mobile devices
- **Netflix-Style UI** - Dark theme with modern, clean design

### New Features in v2.0
✨ **Categories Page** - Browse all movie genres with visual cards  
✨ **Favorites Collection** - Personal watchlist with statistics  
✨ **Advanced Search** - Filter by category, rating, year, and more  
✨ **Enhanced Navigation** - Easy access to all features  
✨ **Share Functionality** - Copy movie links to clipboard  
✨ **8 Sort Options** - Sort by rating, title, year, duration  

## 🛠️ Technologies Used

- **PHP 7+** (Procedural) - Server-side logic
- **MySQL 8.0** - Database management
- **HTML5** - Page structure
- **CSS3** - Styling and animations
- **JavaScript** - Interactive features
- **Sessions** - Favorites management

## 📦 Installation & Setup

### Prerequisites

- XAMPP (or any PHP/MySQL environment)
- Web browser

### Step 1: Copy Files

Copy the entire `netflix` folder to your XAMPP `htdocs` directory:
```
C:\xampp\htdocs\netflix\
```

### Step 2: Start XAMPP

1. Open XAMPP Control Panel
2. Start **Apache** server
3. Start **MySQL** server

### Step 3: Create Database

1. Open your browser and go to: `http://localhost/phpmyadmin`
2. Click on **SQL** tab
3. Copy and paste the entire contents of `database.sql` file
4. Click **Go** to execute the SQL queries

This will create:
- A database named `movie_catalog`
- Two tables: `categories` and `movies`
- Sample data with 16 movies and 8 categories

### Step 4: Configure Database Connection

Open `db.php` and verify these settings match your XAMPP setup:

```php
define('DB_HOST', 'localhost');     // Usually localhost
define('DB_USER', 'root');          // Default XAMPP user
define('DB_PASS', '');              // Default XAMPP password (empty)
define('DB_NAME', 'movie_catalog'); // Database name
```

### Step 5: Run the Application

Open your browser and navigate to:
```
http://localhost/netflix/
```

## 📁 File Structure

```
netflix/
│
├── index.php           # Main page - displays movie catalog
├── db.php              # Database connection configuration
├── style.css           # All CSS styling (Netflix-inspired)
├── script.js           # JavaScript for interactive features
├── database.sql        # Database schema and sample data
└── README.md           # This file (setup instructions)
```

## 🎨 Design Features

### Color Scheme
- **Primary Red**: #e50914 (Netflix red for branding)
- **Background**: #141414 (Dark background)
- **Cards**: #1a1a1a (Slightly lighter dark)
- **Text**: #ffffff (White for contrast)

### Key Components
- Sticky navigation header
- Hero banner section
- Search and filter bar
- Responsive movie grid
- Hover effects on cards
- Footer with site info

## 🔧 Customization

### Adding More Movies

1. Go to phpMyAdmin: `http://localhost/phpmyadmin`
2. Select `movie_catalog` database
3. Click on `movies` table
4. Click **Insert** tab
5. Fill in the movie details and click **Go**

### Changing Colors

Open `style.css` and modify the color variables:
- Search for `#e50914` to change the primary red color
- Search for `#141414` to change the background color

### Adding New Categories

1. Go to phpMyAdmin
2. Insert into `categories` table
3. New category will appear in the filter dropdown

## 🎯 How It Works

### Database Connection (`db.php`)
- Establishes connection to MySQL database
- Uses mysqli extension
- Includes error handling

### Main Page (`index.php`)
1. Includes database connection
2. Processes search and filter queries
3. Retrieves movies from database
4. Displays movies in responsive grid
5. Handles no results scenario

### Search & Filter
- **Search**: Looks for matches in movie title and description
- **Category Filter**: Shows only movies from selected category
- **Clear Filters**: Resets all filters

### JavaScript Features (`script.js`)
- Smooth scrolling
- Scroll animations for movie cards
- Keyboard shortcuts (Ctrl+K for search)
- Sticky header with scroll effect

## 💡 Usage Tips

1. **Search**: Type any keyword and press Enter or click Search
2. **Filter**: Select a category from dropdown (auto-submits)
3. **Clear**: Click "Clear Filters" to reset
4. **Keyboard Shortcut**: Press Ctrl+K (or Cmd+K on Mac) to focus search
5. **Responsive**: Resize browser to see mobile/tablet view

## 🚀 Future Enhancements (Optional)

For students who want to expand the project:

- [ ] Add movie details page (separate PHP file)
- [ ] Implement user login/registration
- [ ] Add favorite/watchlist feature
- [ ] Include movie ratings and reviews
- [ ] Add admin panel to manage movies
- [ ] Implement pagination for large datasets
- [ ] Add video player integration
- [ ] Create an API endpoint for mobile apps

## 📚 Learning Outcomes

This project demonstrates:
- PHP basics (variables, functions, loops)
- MySQL database operations (SELECT, JOIN)
- SQL injection prevention (mysqli_real_escape_string)
- HTML form handling (GET method)
- CSS Grid and Flexbox layouts
- Responsive web design
- JavaScript DOM manipulation
- Modern web design principles

## 🐛 Troubleshooting

### Database Connection Error
- Make sure Apache and MySQL are running in XAMPP
- Check database credentials in `db.php`
- Verify database was created successfully

### Movies Not Displaying
- Check if database has data: Run `SELECT * FROM movies` in phpMyAdmin
- Look for PHP errors (enable error reporting in php.ini)

### Styling Issues
- Clear browser cache (Ctrl+F5)
- Check if `style.css` is loading in browser console

### Search Not Working
- Verify form method is GET
- Check if `$_GET['search']` is being received

## 👨‍🎓 School Project Notes

This project is designed to be:
- **Beginner-friendly**: Clear comments and simple logic
- **Educational**: Demonstrates core web development concepts
- **Complete**: Includes all necessary files
- **Customizable**: Easy to modify and extend
- **Well-documented**: Comprehensive README and code comments

## 📝 Credits

Created as a school project example for learning PHP and web development.

---

**Happy Coding! 🎬🍿**
