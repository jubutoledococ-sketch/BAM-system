<?php
/**
 * Categories Page
 * ===============
 * Browse all movies organized by categories
 */

session_start();
require_once 'db.php';

// Get selected category filter
$selected_category = isset($_GET['category']) ? (int)$_GET['category'] : 0;

// Get sorting option
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'rating_desc';

// Build sort query
$sort_sql = match($sort) {
    'title_asc' => 'ORDER BY m.title ASC',
    'title_desc' => 'ORDER BY m.title DESC',
    'year_asc' => 'ORDER BY m.year ASC',
    'year_desc' => 'ORDER BY m.year DESC',
    'rating_asc' => 'ORDER BY m.rating ASC',
    default => 'ORDER BY m.rating DESC'
};

// Get all categories with movie count
$categories_sql = "SELECT c.*, COUNT(mc.movie_id) as movie_count 
                   FROM categories c 
                   LEFT JOIN movie_category mc ON c.id = mc.category_id 
                   GROUP BY c.id 
                   ORDER BY c.name";
$categories_result = mysqli_query($conn, $categories_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Browse Categories - MovieStream</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .categories-page {
            padding: 100px 0 60px;
            min-height: 100vh;
        }
        
        .page-header {
            margin-bottom: 40px;
        }
        
        .page-title {
            font-size: 42px;
            color: #ffffff;
            margin-bottom: 15px;
        }
        
        .categories-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 30px;
            margin-bottom: 50px;
        }
        
        .category-card {
            background: linear-gradient(145deg, #1a1a1a 0%, #0f0f0f 100%);
            border-radius: 12px;
            padding: 30px;
            border: 1px solid rgba(255, 255, 255, 0.05);
            transition: all 0.3s ease;
            cursor: pointer;
            text-decoration: none;
            display: block;
        }
        
        .category-card:hover {
            transform: translateY(-5px);
            border-color: rgba(229, 9, 20, 0.5);
            box-shadow: 0 15px 40px rgba(229, 9, 20, 0.3);
        }
        
        .category-card.active {
            border-color: #e50914;
            background: linear-gradient(145deg, #2a0f10 0%, #1a0a0a 100%);
        }
        
        .category-name {
            font-size: 24px;
            color: #ffffff;
            margin-bottom: 10px;
            font-weight: bold;
        }
        
        .category-count {
            font-size: 14px;
            color: #b3b3b3;
            margin-bottom: 15px;
        }
        
        .category-description {
            font-size: 14px;
            color: #999;
            line-height: 1.6;
        }
        
        .filter-section {
            background: rgba(255, 255, 255, 0.03);
            padding: 25px;
            border-radius: 8px;
            margin-bottom: 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
        }
        
        .filter-group {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .filter-label {
            color: #b3b3b3;
            font-size: 14px;
        }
        
        .filter-select {
            background: rgba(255, 255, 255, 0.05);
            color: #ffffff;
            border: 1px solid rgba(255, 255, 255, 0.1);
            padding: 10px 15px;
            border-radius: 6px;
            font-size: 14px;
            cursor: pointer;
        }
        
        .clear-filter-btn {
            background: rgba(229, 9, 20, 0.2);
            color: #e50914;
            border: 1px solid #e50914;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .clear-filter-btn:hover {
            background: #e50914;
            color: white;
        }
        
        .results-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        
        .results-count {
            font-size: 18px;
            color: #b3b3b3;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="nav-wrapper">
                <div class="logo">
                    <h1>🎬 MovieStream</h1>
                </div>
                <nav class="nav-menu">
                    <a href="index.php" class="nav-link">Home</a>
                    <a href="categories.php" class="nav-link active">Categories</a>
                    <a href="favorites.php" class="nav-link">Favorites</a>
                    <a href="#" class="nav-link" onclick="openAboutModal(event)">About us</a>
                </nav>
                <div class="user-account">
                    <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
                        <span class="welcome-user">👤 <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                        <a href="logout.php" class="logout-link">Logout</a>
                    <?php else: ?>
                        <a href="login.php" class="login-link">Sign In</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <section class="categories-page">
        <div class="container">
            <div class="page-header">
                <h1 class="page-title">Browse by Category</h1>
                <p style="color: #b3b3b3; font-size: 16px;">Explore our complete collection of movie categories</p>
            </div>

            <!-- Categories Grid -->
            <div class="categories-grid">
                <?php while ($category = mysqli_fetch_assoc($categories_result)): ?>
                          <a href="#movies-section"
                              class="category-card <?php echo $selected_category == $category['id'] ? 'active' : ''; ?>"
                              onclick="loadCategoryMovies(event, <?php echo $category['id']; ?>)">
                        <h3 class="category-name"><?php echo htmlspecialchars($category['name']); ?></h3>
                        <p class="category-count"><?php echo $category['movie_count']; ?> movies</p>
                        <p class="category-description"><?php echo htmlspecialchars($category['description']); ?></p>
                    </a>
                <?php endwhile; ?>
            </div>

            <div id="movies-section">
                <!-- Movies will be loaded dynamically via AJAX -->
            </div>
                <!-- Filter and Sort Options -->
                <div class="filter-section">
                    <div class="filter-group">
                        <span class="filter-label">Sort by:</span>
                        <select class="filter-select" onchange="window.location.href='categories.php?category=<?php echo $selected_category; ?>&sort=' + this.value">
                            <option value="rating_desc" <?php echo $sort == 'rating_desc' ? 'selected' : ''; ?>>Rating (High to Low)</option>
                            <option value="rating_asc" <?php echo $sort == 'rating_asc' ? 'selected' : ''; ?>>Rating (Low to High)</option>
                            <option value="title_asc" <?php echo $sort == 'title_asc' ? 'selected' : ''; ?>>Title (A-Z)</option>
                            <option value="title_desc" <?php echo $sort == 'title_desc' ? 'selected' : ''; ?>>Title (Z-A)</option>
                            <option value="year_desc" <?php echo $sort == 'year_desc' ? 'selected' : ''; ?>>Year (Newest)</option>
                            <option value="year_asc" <?php echo $sort == 'year_asc' ? 'selected' : ''; ?>>Year (Oldest)</option>
                        </select>
                    </div>
                    <button class="clear-filter-btn" onclick="window.location.href='categories.php'">
                        Clear Filter
                    </button>
                </div>

                <!-- Movies will be loaded dynamically via AJAX -->
        </div>
    </section>
<!-- Footer Section -->
    <footer class="footer" style="background: linear-gradient(135deg, #181818 0%, #1a1a1a 100%); color: #b3b3b3; padding: 40px 0 0 0; margin-top: 60px; border-top: 1px solid #222;">
        <div class="container">
            <div class="footer-content" style="display: flex; flex-wrap: wrap; justify-content: space-between; gap: 40px;">
                <div class="footer-section" style="flex: 1 1 220px; min-width: 200px;">
                    <h4 style="color: #e50914; font-size: 24px; margin-bottom: 10px;">🎬 MovieStream</h4>
                    <p style="color: #ccc;">Your ultimate movie catalog for school projects.<br>Enjoy browsing and discovering new favorites!</p>
                    
                </div>
                <div class="footer-section" style="flex: 1 1 180px; min-width: 160px;">
                    <h4 style="color: #e50914; font-size: 18px; margin-bottom: 10px;">Quick Links</h4>
                    <ul style="list-style: none; padding: 0; margin: 0;">
                        <li><a href="index.php" style="color: #b3b3b3; text-decoration: none;">Home</a></li>
                        <li><a href="categories.php" style="color: #b3b3b3; text-decoration: none;">Categories</a></li>
                        <li><a href="favorites.php" style="color: #b3b3b3; text-decoration: none;">Favorites</a></li>
                        <a href="#" class="nav-link" onclick="openAboutModal(event)">About us</a>
                    </ul>
                </div>
                <div class="footer-section" style="flex: 1 1 180px; min-width: 160px;">
                    <h4 style="color: #e50914; font-size: 18px; margin-bottom: 10px;">Status</h4>
                    <p style="margin: 0 0 8px 0;">Total Movies: <?php 
                        $count_sql = "SELECT COUNT(*) as total FROM movies";
                        $count_result = mysqli_query($conn, $count_sql);
                        $count = mysqli_fetch_assoc($count_result);
                        echo $count['total'];
                    ?></p>
                    <p style="margin: 0;">Categories: <?php 
                        $cat_count_sql = "SELECT COUNT(*) as total FROM categories";
                        $cat_count_result = mysqli_query($conn, $cat_count_sql);
                        $cat_count = mysqli_fetch_assoc($cat_count_result);
                        echo $cat_count['total'];
                    ?></p>
                </div>
            </div>
            <div class="footer-bottom" style="text-align: center; margin-top: 32px; padding: 18px 0 0 0; border-top: 1px solid #222; color: #666; font-size: 15px;">
                <p>Submitted by Justin Joshua Toledo</p>
            </div>
        </div>
    </footer>

    <style>
    .movies-row-wrapper {
        display: flex;
        align-items: center;
        margin-bottom: 40px;
        overflow-x: auto;
        padding: 0 0 20px 0;
    }
    .movies-row {
        display: flex;
        gap: 24px;
        flex-wrap: wrap;
        max-width: 1400px;
        margin: 0 auto;
        scroll-behavior: smooth;
        padding: 10px 0;
    }
    .movie-card-horizontal {
        background: linear-gradient(145deg, #1a1a1a 0%, #0f0f0f 100%);
        border-radius: 12px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.6);
        border: 1px solid rgba(229,9,20,0.2);
        min-width: 320px;
        max-width: 340px;
        flex: 1 1 23%;
        cursor: pointer;
        display: flex;
        flex-direction: column;
        transition: transform 0.3s;
    }
    .movie-card-horizontal:hover {
        transform: translateY(-6px) scale(1.03);
        border-color: #e50914;
    }
    .movie-poster-horizontal {
        position: relative;
        height: 180px;
        border-radius: 12px 12px 0 0;
        overflow: hidden;
    }
    .movie-poster-horizontal img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        border-radius: 12px 12px 0 0;
    }
    .movie-overlay-horizontal {
        position: absolute;
        top: 0; left: 0; width: 100%; height: 100%;
        background: linear-gradient(180deg, rgba(0,0,0,0.2) 0%, rgba(0,0,0,0.7) 100%);
        display: flex;
        flex-direction: column;
        justify-content: flex-end;
        align-items: flex-end;
        padding: 12px;
    }
    .movie-rating-horizontal {
        background: #e50914;
        color: #fff;
        padding: 4px 10px;
        border-radius: 6px;
        font-size: 15px;
        margin-bottom: 6px;
    }
    .movie-play-icon {
        font-size: 22px;
        color: #fff;
        background: rgba(229,9,20,0.7);
        border-radius: 50%;
        padding: 6px;
        margin-bottom: 6px;
    }
    .movie-info-horizontal {
        padding: 18px 16px 16px 16px;
        flex: 1;
        display: flex;
        flex-direction: column;
    }
    .movie-title-horizontal {
        font-size: 20px;
        color: #fff;
        margin-bottom: 8px;
        font-weight: bold;
    }
    .movie-meta-horizontal {
        font-size: 14px;
        color: #b3b3b3;
        margin-bottom: 10px;
        display: flex;
        gap: 12px;
    }
    .movie-description-horizontal {
        font-size: 14px;
        color: #ccc;
        margin-bottom: 12px;
        flex: 1;
    }
    .watch-btn {
        background: linear-gradient(135deg, #e50914 0%, #b20710 100%);
        color: white;
        border: none;
        border-radius: 6px;
        font-size: 16px;
        font-weight: bold;
        cursor: pointer;
        transition: all 0.3s ease;
        text-transform: uppercase;
        letter-spacing: 1px;
        margin-top: 10px;
        padding: 12px 0;
    }
    .watch-btn:hover {
        background: linear-gradient(135deg, #ff1a1a 0%, #e50914 100%);
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(229, 9, 20, 0.5);
    }
    </style>
    <script>
    function loadCategoryMovies(event, categoryId) {
        event.preventDefault();
        // Highlight selected category
        document.querySelectorAll('.category-card').forEach(card => card.classList.remove('active'));
        event.currentTarget.classList.add('active');
        // Update URL without reload
        const url = new URL(window.location.href);
        url.searchParams.set('category', categoryId);
        history.pushState({}, '', url);
        // Fetch movies via AJAX
        fetch('categories_ajax.php?category=' + categoryId)
            .then(response => response.text())
            .then(html => {
                document.getElementById('movies-section').innerHTML = html;
                // Scroll to movies section
                var moviesSection = document.getElementById('results-header');
                if (moviesSection) {
                    moviesSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            });
    }
    function handleMovieClick(id) {
        var loggedIn = <?php echo isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true ? 'true' : 'false'; ?>;
        if (loggedIn) {
            window.location.href = 'movie.php?id=' + id;
        } else {
            window.location.href = 'login.php?redirect=' + encodeURIComponent('movie.php?id=' + id);
        }
    }
    function scrollRow(button, direction) {
        const wrapper = button.parentElement;
        const moviesRow = wrapper.querySelector('.movies-row');
        const scrollAmount = 340 + 24; // card width + gap
        moviesRow.scrollBy({ left: direction === 'left' ? -scrollAmount : scrollAmount, behavior: 'smooth' });
    }
    </script>
    <div id="aboutModal" style="display:none; position:fixed; z-index:9999; left:0; top:0; width:100vw; height:100vh; background:rgba(0,0,0,0.7); align-items:center; justify-content:center;">
        <div style="background:#181818; color:#fff; border-radius:12px; max-width:500px; width:90vw; margin:auto; padding:36px 28px 28px 28px; position:relative; box-shadow:0 8px 32px rgba(0,0,0,0.7);">
            <button onclick="closeAboutModal()" style="position:absolute; top:16px; right:18px; background:none; border:none; color:#e50914; font-size:28px; cursor:pointer;">&times;</button>
            <h2 style="color:#e50914; margin-bottom:12px;">About MovieStream</h2>
            <p style="font-size:16px; color:#ccc; margin-bottom:18px;">MovieStream is a school project designed to help students learn web development by building a modern movie catalog. Browse, search, and discover movies by category, rating, and more. This project demonstrates PHP, MySQL, and responsive web design best practices.</p>
            <h3 style="color:#e50914; margin-bottom:8px; font-size:18px;">Our Team</h3>
            <ul style="color:#b3b3b3; font-size:15px; margin-bottom:0; padding-left:18px;">
                <li>Developer: <strong>Justin Joshua Toledo</strong></li>
                <li>Course: <strong>BSIT</strong></li>
            </ul>
        </div>
    </div>

    <script>
    function openAboutModal(e) {
        if(e) e.preventDefault();
        document.getElementById('aboutModal').style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }
    function closeAboutModal() {
        document.getElementById('aboutModal').style.display = 'none';
        document.body.style.overflow = '';
    }
    // Optional: Close modal on background click
    document.addEventListener('DOMContentLoaded', function() {
        var modal = document.getElementById('aboutModal');
        if(modal) {
            modal.addEventListener('click', function(e) {
                if(e.target === modal) closeAboutModal();
            });
        }
    });
    </script>
    </script>
    <script src="script.js"></script>
</body>
</html>

<?php mysqli_close($conn); ?>
