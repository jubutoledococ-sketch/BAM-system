<?php
// categories_ajax.php
// Returns movies for a given category as HTML (for AJAX)

require_once 'db.php';

$category = isset($_GET['category']) ? (int)$_GET['category'] : 0;
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'rating_desc';

$sort_sql = match($sort) {
    'title_asc' => 'ORDER BY m.title ASC',
    'title_desc' => 'ORDER BY m.title DESC',
    'year_asc' => 'ORDER BY m.year ASC',
    'year_desc' => 'ORDER BY m.year DESC',
    'rating_asc' => 'ORDER BY m.rating ASC',
    default => 'ORDER BY m.rating DESC'
};

if ($category > 0) {
    echo '<div class="results-header" id="results-header">';
    $movies_sql = "SELECT DISTINCT m.* FROM movies m JOIN movie_category mc ON m.id = mc.movie_id WHERE mc.category_id = ? $sort_sql";
    $stmt = mysqli_prepare($conn, $movies_sql);
    mysqli_stmt_bind_param($stmt, "i", $category);
    mysqli_stmt_execute($stmt);
    $movies_result = mysqli_stmt_get_result($stmt);
    $movie_count = mysqli_num_rows($movies_result);
    echo '<h2 class="results-count">' . $movie_count . ' movies found</h2>';
    echo '</div>';
    if ($movie_count > 0) {
        echo '<div class="movies-row-wrapper">';
        echo '<div class="movies-row">';
        while ($movie = mysqli_fetch_assoc($movies_result)) {
            echo '<div class="movie-card-horizontal trending-card" onclick="handleMovieClick(' . $movie['id'] . ')">';
            echo '<div class="movie-poster-horizontal">';
            echo '<img src="' . htmlspecialchars($movie['image_url']) . '" alt="' . htmlspecialchars($movie['title']) . '">';
            echo '<div class="movie-overlay-horizontal">';
            echo '</div>';
            echo '</div>';
            echo '<div class="movie-info-horizontal">';
            echo '<h3 class="movie-title-horizontal">' . htmlspecialchars($movie['title']) . '</h3>';
            echo '<div class="movie-meta-horizontal">';
            echo '<span>' . $movie['year'] . '</span>';
            echo '<span>' . $movie['duration'] . ' min</span>';
            echo '</div>';
            $desc = $movie['description'];
            echo '<p class="movie-description-horizontal">' . htmlspecialchars(strlen($desc) > 120 ? substr($desc, 0, 120) . '...' : $desc) . '</p>';
            echo '<button class="watch-btn" type="button" onclick="event.stopPropagation(); handleMovieClick(' . $movie['id'] . ')">▶ Watch Now</button>';
            echo '</div>';
            echo '</div>';
        }
        echo '</div>';
        echo '</div>';
    }
    mysqli_stmt_close($stmt);
} else {
    echo '<div class="results-header" id="results-header">';
    echo '<h2 class="results-count">Select a category to view movies</h2>';
    echo '</div>';
}
mysqli_close($conn);
