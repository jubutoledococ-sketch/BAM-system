-- ============================================
-- Movie Catalog Database Schema
-- For School Project - Beginner Friendly
-- ============================================

-- Create the database
CREATE DATABASE IF NOT EXISTS movie_catalog;
USE movie_catalog;

-- ============================================
-- Drop existing tables to ensure clean slate
-- ============================================
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS movie_category;
DROP TABLE IF EXISTS movies;
DROP TABLE IF EXISTS categories;
SET FOREIGN_KEY_CHECKS = 1;

-- ============================================
-- Table: categories
-- Purpose: Stores different movie genres/categories
-- Explanation: This table holds all available categories (Action, Drama, etc.)
--              Each category has a unique name and tracks when it was created
-- ============================================
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE,
    description TEXT COMMENT 'Brief description of the category',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- Table: movies
-- Purpose: Stores all movie information
-- Explanation: This is the main table containing movie details like title,
--              description, year, duration, and rating. Each movie is
--              independent and can belong to multiple categories via
--              the movie_category table (many-to-many relationship)
-- ============================================
CREATE TABLE movies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    year INT,
    duration INT COMMENT 'Duration in minutes',
    rating DECIMAL(3,1) COMMENT 'Rating out of 10',
    image_url VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- Table: movie_category
-- Purpose: Junction table for many-to-many relationship
-- Explanation: This table links movies and categories together. One movie
--              can have multiple categories (e.g., Action + Thriller),
--              and one category can have multiple movies. This is called
--              a many-to-many relationship and requires a junction table.
-- ============================================
CREATE TABLE movie_category (
    id INT AUTO_INCREMENT PRIMARY KEY,
    movie_id INT NOT NULL,
    category_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE,
    UNIQUE KEY unique_movie_category (movie_id, category_id)
);

-- ============================================
-- Insert Sample Categories
-- ============================================

INSERT INTO categories (name, description) VALUES
('Action', 'High-energy movies with exciting stunts and chase sequences'),
('Comedy', 'Funny and lighthearted movies designed to entertain'),
('Drama', 'Serious narratives focused on character development and emotion'),
('Horror', 'Scary movies designed to frighten and create suspense'),
('Science Fiction', 'Futuristic and imaginative stories exploring technology and space'),
('Romance', 'Love stories centered around romantic relationships'),
('Thriller', 'Suspenseful movies that keep you on the edge of your seat'),
('Animation', 'Animated films for all ages');

-- ============================================
-- Table: users
-- Purpose: Stores user information for login and profile
-- Explanation: This table holds user credentials and basic profile info.
-- ============================================
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- Table: movie_plays
-- Purpose: Tracks every Play Now click/watch event
-- ============================================
CREATE TABLE movie_plays (
    id INT AUTO_INCREMENT PRIMARY KEY,
    movie_id INT NOT NULL,
    user_id INT NULL,
    username VARCHAR(50) NOT NULL,
    played_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_movie_plays_movie (movie_id),
    INDEX idx_movie_plays_user (user_id),
    INDEX idx_movie_plays_username (username),
    INDEX idx_movie_plays_played_at (played_at)
);
INSERT INTO movies (title, description, year, duration, rating, image_url) VALUES

('Laugh Out Loud', 'A hilarious comedy about friends navigating life\'s unexpected moments with humor and heart.', 2022, 98, 7.2, 'https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=300&h=450&fit=crop'),

('Silent Tears', 'An emotional drama exploring family bonds and the power of forgiveness.', 2023, 128, 8.9, 'https://images.unsplash.com/photo-1485846234645-a62644f84728?w=300&h=450&fit=crop'),

('Nightmare House', 'A spine-chilling horror experience in an abandoned mansion with dark secrets.', 2021, 105, 7.8, 'https://images.unsplash.com/photo-1509248961158-e54f6934749c?w=300&h=450&fit=crop'),

('Galaxy Explorers', 'Epic space adventure following brave explorers discovering new worlds and alien civilizations.', 2023, 156, 9.1, 'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=300&h=450&fit=crop'),

('Love in Paris', 'A romantic tale of two strangers who meet in the city of love and change each other\'s lives forever.', 2022, 112, 7.5, 'https://images.unsplash.com/photo-1518199266791-5375a83190b7?w=300&h=450&fit=crop'),

('The Last Code', 'A tech thriller about a programmer who discovers a dangerous conspiracy.', 2023, 118, 8.2, 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=300&h=450&fit=crop'),

('Magic Kingdom', 'Animated adventure featuring magical creatures and brave young heroes on an epic quest.', 2022, 95, 8.7, 'https://images.unsplash.com/photo-1518173946687-a4c8892bbd9f?w=300&h=450&fit=crop'),

('Speed Chase', 'High-octane action with incredible car chases and explosive stunts.', 2023, 125, 7.9, 'https://images.unsplash.com/photo-1542282088-fe8426682b8f?w=300&h=450&fit=crop'),

('Office Chaos', 'Workplace comedy showing the funny side of corporate life and office politics.', 2021, 89, 6.8, 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=300&h=450&fit=crop'),

('The Forgotten', 'Powerful drama about memory, identity, and finding your way back home.', 2023, 134, 8.4, 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=300&h=450&fit=crop'),

('Shadow Realm', 'Terror awaits in this supernatural horror about entities from another dimension.', 2022, 101, 7.6, 'https://images.unsplash.com/photo-1509822929063-6b6cfc9b42f2?w=300&h=450&fit=crop'),

('Star Warriors', 'Sci-fi epic featuring intergalactic battles and the fight for the universe.', 2023, 148, 8.8, 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=300&h=450&fit=crop'),

('Summer Romance', 'Heartwarming love story set during an unforgettable summer vacation.', 2022, 106, 7.3, 'https://images.unsplash.com/photo-1464207687429-7505649dae38?w=300&h=450&fit=crop'),

('Decoded', 'Suspenseful thriller following a detective solving cryptic messages from a killer.', 2023, 122, 8.1, 'https://images.unsplash.com/photo-1485846234645-a62644f84728?w=300&h=450&fit=crop'),

('Adventure Kids', 'Fun animated movie about kids discovering a magical world in their backyard.', 2021, 92, 7.9, 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=300&h=450&fit=crop');

-- ============================================
-- Insert Movie-Category Relationships
-- This links movies to their categories (many-to-many)
-- Note: Some movies belong to multiple categories, creating multiple rows
-- ============================================
INSERT INTO movie_category (movie_id, category_id) VALUES
-- The Dark Journey: Action + Thriller
(1, 1), (1, 7),

-- Laugh Out Loud: Comedy
(2, 2),

-- Silent Tears: Drama
(3, 3),

-- Nightmare House: Horror + Thriller
(4, 4), (4, 7),

-- Galaxy Explorers: Science Fiction + Action
(5, 5), (5, 1),

-- Love in Paris: Romance + Drama
(6, 6), (6, 3),

-- The Last Code: Thriller + Drama
(7, 7), (7, 3),

-- Magic Kingdom: Animation
(8, 8),

-- Speed Chase: Action + Thriller
(9, 1), (9, 7),

-- Office Chaos: Comedy
(10, 2),

-- The Forgotten: Drama
(11, 3),

-- Shadow Realm: Horror + Thriller
(12, 4), (12, 7),

-- Star Warriors: Science Fiction + Action
(13, 5), (13, 1),

-- Summer Romance: Romance + Comedy
(14, 6), (14, 2),

-- Decoded: Thriller
(15, 7),

-- Adventure Kids: Animation + Comedy
(16, 8), (16, 2);

-- ============================================
-- Useful Queries for Testing
-- ============================================

-- View all movies with their categories (shows multiple rows if movie has multiple categories)
-- SELECT m.*, c.name as category_name 
-- FROM movies m 
-- JOIN movie_category mc ON m.id = mc.movie_id
-- JOIN categories c ON mc.category_id = c.id
-- ORDER BY m.title;

-- Get all categories for a specific movie
-- SELECT c.name 
-- FROM categories c
-- JOIN movie_category mc ON c.id = mc.category_id
-- WHERE mc.movie_id = 1;

-- Search movies by title
-- SELECT DISTINCT m.* FROM movies m WHERE title LIKE '%search_term%';

-- Get all movies in a specific category
-- SELECT m.* 
-- FROM movies m
-- JOIN movie_category mc ON m.id = mc.movie_id
-- JOIN categories c ON mc.category_id = c.id
-- WHERE c.name = 'Action';

-- Count movies per category
-- SELECT c.name, COUNT(mc.movie_id) as movie_count
-- FROM categories c
-- LEFT JOIN movie_category mc ON c.id = mc.category_id
-- GROUP BY c.id, c.name
-- ORDER BY movie_count DESC
