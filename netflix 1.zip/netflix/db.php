<?php
/**
 * Database Connection File
 * ========================
 * This file handles the connection to MySQL database
 * You need to update the credentials based on your setup
 */

// Database configuration constants
// Change these values according to your XAMPP setup
define('DB_HOST', 'localhost');        // Database host (usually localhost)
define('DB_USER', 'root');             // Database username (default: root)
define('DB_PASS', '');                 // Database password (default: empty for XAMPP)
define('DB_NAME', 'movie_catalog');    // Database name

// Create connection to MySQL database
$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check if connection was successful
if (!$conn) {
    // If connection failed, show error message and stop execution
    die("Connection failed: " . mysqli_connect_error());
}

// Optional: Set character encoding to UTF-8 for proper text display
mysqli_set_charset($conn, "utf8");

// Success message (commented out - uncomment for testing)
// echo "Connected successfully to database!";

?>
