<?php
/**
 * Live CSV data feed for Excel dashboard refresh.
 * Usage:
 *   excel_live_data.php?type=movie_user
 *   excel_live_data.php?type=movie_summary
 *   excel_live_data.php?type=user_summary
 */

require_once 'db.php';

$type = isset($_GET['type']) ? $_GET['type'] : 'movie_user';

header('Content-Type: text/csv; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

$out = fopen('php://output', 'w');
if ($out === false) {
    http_response_code(500);
    exit();
}

$createTableSql = "CREATE TABLE IF NOT EXISTS movie_plays (
    id INT AUTO_INCREMENT PRIMARY KEY,
    movie_id INT NOT NULL,
    user_id INT NULL,
    username VARCHAR(50) NOT NULL,
    played_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_movie_plays_movie (movie_id),
    INDEX idx_movie_plays_user (user_id),
    INDEX idx_movie_plays_username (username),
    INDEX idx_movie_plays_played_at (played_at)
)";
mysqli_query($conn, $createTableSql);

if ($type === 'movie_summary') {
    fputcsv($out, ['Movie', 'Play_Count', 'Total_Hours']);
    $sql = "SELECT m.title AS movie_title,
                   COUNT(mp.id) AS play_count,
                   ROUND(COALESCE(SUM(m.duration), 0)/60, 2) AS total_hours
            FROM movies m
            LEFT JOIN movie_plays mp ON mp.movie_id = m.id
            GROUP BY m.id, m.title
            ORDER BY play_count DESC, total_hours DESC, m.title";
} elseif ($type === 'user_summary') {
    fputcsv($out, ['User', 'Email', 'Play_Count', 'Total_Hours']);
    $sql = "SELECT u.username,
                   u.email,
                   COUNT(mp.id) AS play_count,
                   ROUND(COALESCE(SUM(m.duration), 0)/60, 2) AS total_hours
            FROM users u
            LEFT JOIN movie_plays mp ON (mp.user_id = u.id OR (mp.user_id IS NULL AND mp.username = u.username))
            LEFT JOIN movies m ON m.id = mp.movie_id
            GROUP BY u.id, u.username, u.email
            ORDER BY play_count DESC, total_hours DESC, u.username";
} else {
    fputcsv($out, ['Movie_ID', 'Movie', 'User_ID', 'User', 'Email', 'Hours_Per_Movie', 'Played_At']);
    $sql = "SELECT m.id AS movie_id,
                   m.title AS movie_title,
                   COALESCE(u.id, mp.user_id) AS user_id,
                   COALESCE(u.username, mp.username) AS username,
                   u.email,
                   ROUND(m.duration / 60, 2) AS hours_per_movie,
                   mp.played_at
            FROM movie_plays mp
            JOIN movies m ON m.id = mp.movie_id
            LEFT JOIN users u ON u.id = mp.user_id
            ORDER BY mp.played_at DESC, m.title, username";
}

$result = mysqli_query($conn, $sql);
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        fputcsv($out, $row);
    }
}

if ($result) {
    mysqli_free_result($result);
}
fclose($out);
mysqli_close($conn);
