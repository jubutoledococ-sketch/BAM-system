<?php
require_once 'db.php';
header('Content-Type: text/csv; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');
$out = fopen('php://output', 'w');
$createTableSql = "CREATE TABLE IF NOT EXISTS movie_plays (
    id INT AUTO_INCREMENT PRIMARY KEY,
    movie_id INT NOT NULL,
    user_id INT NULL,
    username VARCHAR(50) NOT NULL,
    played_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_movie_plays_movie (movie_id),
    INDEX idx_movie_plays_user (user_id),
    INDEX idx_movie_plays_username (username),
    INDEX idx_movie_plays_played_at (played_at)
)";
mysqli_query($conn, $createTableSql);
fputcsv($out, ['Movie', 'Play_Count', 'Total_Hours']);
$sql = "SELECT m.title AS movie_title, COUNT(mp.id) AS play_count, ROUND(COALESCE(SUM(m.duration), 0)/60, 2) AS total_hours FROM movies m LEFT JOIN movie_plays mp ON mp.movie_id = m.id GROUP BY m.id, m.title ORDER BY play_count DESC, total_hours DESC, m.title";
$result = mysqli_query($conn, $sql);
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        fputcsv($out, $row);
    }
    mysqli_free_result($result);
}
fclose($out);
mysqli_close($conn);
