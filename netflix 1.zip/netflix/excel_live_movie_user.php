<?php
require_once 'db.php';
header('Content-Type: text/csv; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');
$out = fopen('php://output', 'w');
$createTableSql = "CREATE TABLE IF NOT EXISTS movie_plays (
    id INT AUTO_INCREMENT PRIMARY KEY,
    movie_id INT NOT NULL,
    user_id INT NULL,
    username VARCHAR(50) NOT NULL,
    played_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_movie_plays_movie (movie_id),
    INDEX idx_movie_plays_user (user_id),
    INDEX idx_movie_plays_username (username),
    INDEX idx_movie_plays_played_at (played_at)
)";
mysqli_query($conn, $createTableSql);
fputcsv($out, ['Movie_ID', 'Movie', 'User_ID', 'User', 'Email', 'Hours_Per_Movie', 'Played_At']);
$sql = "SELECT m.id AS movie_id, m.title AS movie_title, COALESCE(u.id, mp.user_id) AS user_id, COALESCE(u.username, mp.username) AS username, u.email, ROUND(m.duration / 60, 2) AS hours_per_movie, mp.played_at FROM movie_plays mp JOIN movies m ON m.id = mp.movie_id LEFT JOIN users u ON u.id = mp.user_id ORDER BY mp.played_at DESC, m.title, username";
$result = mysqli_query($conn, $sql);
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        fputcsv($out, $row);
    }
    mysqli_free_result($result);
}
fclose($out);
mysqli_close($conn);
