<?php
/**
 * Favorites Page
 * ==============
 * Manage user's favorite movies (stored in session/localStorage)
 */

session_start();
require_once 'db.php';

// Initialize favorites in session if not exists
if (!isset($_SESSION['favorites'])) {
    $_SESSION['favorites'] = [];
}

// Handle add/remove favorite actions
if (isset($_GET['action']) && isset($_GET['id'])) {
    $movie_id = (int)$_GET['id'];
    
    if ($_GET['action'] == 'add') {
        if (!in_array($movie_id, $_SESSION['favorites'])) {
            $_SESSION['favorites'][] = $movie_id;
        }
    } elseif ($_GET['action'] == 'remove') {
        $_SESSION['favorites'] = array_filter($_SESSION['favorites'], fn($id) => $id != $movie_id);
    }
    
    // Redirect back to referring page or favorites
    $redirect = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'favorites.php';
    header("Location: $redirect");
    exit();
}

// Get favorite movies
$favorites = $_SESSION['favorites'];
$favorite_movies = [];

if (!empty($favorites)) {
    $ids = implode(',', array_map('intval', $favorites));
    $sql = "SELECT * FROM movies WHERE id IN ($ids) ORDER BY rating DESC";
    $result = mysqli_query($conn, $sql);
    while ($movie = mysqli_fetch_assoc($result)) {
        $favorite_movies[] = $movie;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Favorites - MovieStream</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .favorites-page {
            padding: 100px 0 60px;
            min-height: 100vh;
        }
        
        .empty-favorites {
            text-align: center;
            padding: 80px 20px;
        }
        
        .empty-favorites h2 {
            font-size: 32px;
            color: #ffffff;
            margin-bottom: 15px;
        }
        
        .empty-favorites p {
            font-size: 18px;
            color: #b3b3b3;
            margin-bottom: 30px;
        }
        
        .browse-btn {
            display: inline-block;
            background: linear-gradient(135deg, #e50914, #b20710);
            color: white;
            padding: 15px 35px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 16px;
            font-weight: bold;
            transition: transform 0.3s ease;
        }
        
        .browse-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(229, 9, 20, 0.4);
        }
        
        .favorites-stats {
            background: rgba(255, 255, 255, 0.03);
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .stats-item {
            text-align: center;
        }
        
        .stats-value {
            font-size: 32px;
            color: #e50914;
            font-weight: bold;
        }
        
        .stats-label {
            font-size: 14px;
            color: #b3b3b3;
            margin-top: 5px;
        }
        
        .remove-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            background: rgba(229, 9, 20, 0.9);
            color: white;
            border: none;
            border-radius: 50%;
            width: 35px;
            height: 35px;
            font-size: 20px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: all 0.3s ease;
            z-index: 10;
        }
        
        .movie-card:hover .remove-btn {
            opacity: 1;
        }
        
        .remove-btn:hover {
            background: #b20710;
            transform: scale(1.1);
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="nav-wrapper">
                <div class="logo">
                    <h1>🎬 MovieStream</h1>
                </div>
                <nav class="nav-menu">
                    <a href="index.php" class="nav-link">Home</a>
                    <a href="categories.php" class="nav-link">Categories</a>
                    <a href="favorites.php" class="nav-link active">Favorites</a>
                    <a href="#" class="nav-link" onclick="openAboutModal(event)">About us</a>
                </nav>
                <div class="user-account">
                    <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
                        <span class="welcome-user">👤 <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                        <a href="logout.php" class="logout-link">Logout</a>
                    <?php else: ?>
                        <a href="login.php" class="login-link">Sign In</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <section class="favorites-page">
        <div class="container">
            <h1 class="page-title" style="font-size: 42px; margin-bottom: 30px;">My Favorites ❤️</h1>

            <?php if (empty($favorite_movies)): ?>
                <div class="empty-favorites">
                    <h2>No favorites yet</h2>
                    <p>Start adding movies to your favorites collection!</p>
                    <a href="index.php" class="browse-btn">Browse Movies</a>
                </div>
            <?php else: ?>
                <!-- Stats -->
                <div class="favorites-stats">
                    <div class="stats-item">
                        <div class="stats-value"><?php echo count($favorite_movies); ?></div>
                        <div class="stats-label">Total Movies</div>
                    </div>
                    <div class="stats-item">
                        <div class="stats-value">
                            <?php 
                            $total_duration = array_sum(array_column($favorite_movies, 'duration'));
                            echo round($total_duration / 60, 1);
                            ?>h
                        </div>
                        <div class="stats-label">Total Duration</div>
                    </div>
                    <div class="stats-item">
                        <div class="stats-value">
                            <?php 
                            $avg_rating = array_sum(array_column($favorite_movies, 'rating')) / count($favorite_movies);
                            echo number_format($avg_rating, 1);
                            ?>
                        </div>
                        <div class="stats-label">Avg Rating</div>
                    </div>
                </div>

                <!-- Movies Grid -->
                <div class="movies-grid">
                    <?php foreach ($favorite_movies as $movie): ?>
                        <div class="movie-card" onclick="window.location.href='movie.php?id=<?php echo $movie['id']; ?>'">
                            <button class="remove-btn" 
                                    onclick="event.stopPropagation(); if(confirm('Remove from favorites?')) window.location.href='favorites.php?action=remove&id=<?php echo $movie['id']; ?>'">
                                ×
                            </button>
                            <div class="movie-poster">
                                <img src="<?php echo htmlspecialchars($movie['image_url']); ?>" 
                                     alt="<?php echo htmlspecialchars($movie['title']); ?>">
                                <div class="movie-overlay">
                                    <div class="movie-rating">⭐ <?php echo $movie['rating']; ?>/10</div>
                                </div>
                            </div>
                            <div class="movie-info">
                                <h3 class="movie-title"><?php echo htmlspecialchars($movie['title']); ?></h3>
                                <div class="movie-meta">
                                    <span class="movie-year"><?php echo $movie['year']; ?></span>
                                    <span class="movie-duration"><?php echo $movie['duration']; ?> min</span>
                                </div>
                                <p class="movie-description">
                                    <?php 
                                    $desc = $movie['description'];
                                    echo htmlspecialchars(strlen($desc) > 100 ? substr($desc, 0, 100) . '...' : $desc);
                                    ?>
                                </p>
                                <button class="watch-btn" onclick="event.stopPropagation(); window.location.href='movie.php?id=<?php echo $movie['id']; ?>'">
                                    ▶ Watch Now
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>
<!-- Footer Section -->
    <footer class="footer" style="background: linear-gradient(135deg, #181818 0%, #1a1a1a 100%); color: #b3b3b3; padding: 40px 0 0 0; margin-top: 60px; border-top: 1px solid #222;">
        <div class="container">
            <div class="footer-content" style="display: flex; flex-wrap: wrap; justify-content: space-between; gap: 40px;">
                <div class="footer-section" style="flex: 1 1 220px; min-width: 200px;">
                    <h4 style="color: #e50914; font-size: 24px; margin-bottom: 10px;">🎬 MovieStream</h4>
                    <p style="color: #ccc;">Your ultimate movie catalog for school projects.<br>Enjoy browsing and discovering new favorites!</p>
                    
                </div>
                <div class="footer-section" style="flex: 1 1 180px; min-width: 160px;">
                    <h4 style="color: #e50914; font-size: 18px; margin-bottom: 10px;">Quick Links</h4>
                    <ul style="list-style: none; padding: 0; margin: 0;">
                        <li><a href="index.php" style="color: #b3b3b3; text-decoration: none;">Home</a></li>
                        <li><a href="categories.php" style="color: #b3b3b3; text-decoration: none;">Categories</a></li>
                        <li><a href="favorites.php" style="color: #b3b3b3; text-decoration: none;">Favorites</a></li>
                        <a href="#" class="nav-link" onclick="openAboutModal(event)">About us</a>
                    </ul>
                </div>
                <div class="footer-section" style="flex: 1 1 180px; min-width: 160px;">
                    <h4 style="color: #e50914; font-size: 18px; margin-bottom: 10px;">Status</h4>
                    <p style="margin: 0 0 8px 0;">Total Movies: <?php 
                        $count_sql = "SELECT COUNT(*) as total FROM movies";
                        $count_result = mysqli_query($conn, $count_sql);
                        $count = mysqli_fetch_assoc($count_result);
                        echo $count['total'];
                    ?></p>
                    <p style="margin: 0;">Categories: <?php 
                        $cat_count_sql = "SELECT COUNT(*) as total FROM categories";
                        $cat_count_result = mysqli_query($conn, $cat_count_sql);
                        $cat_count = mysqli_fetch_assoc($cat_count_result);
                        echo $cat_count['total'];
                    ?></p>
                </div>
            </div>
            <div class="footer-bottom" style="text-align: center; margin-top: 32px; padding: 18px 0 0 0; border-top: 1px solid #222; color: #666; font-size: 15px;">
                <p>Submitted by Justin Joshua Toledo</p>
            </div>
        </div>
    </footer>

    <script src="script.js"></script>
        </script>
    <div id="aboutModal" style="display:none; position:fixed; z-index:9999; left:0; top:0; width:100vw; height:100vh; background:rgba(0,0,0,0.7); align-items:center; justify-content:center;">
        <div style="background:#181818; color:#fff; border-radius:12px; max-width:500px; width:90vw; margin:auto; padding:36px 28px 28px 28px; position:relative; box-shadow:0 8px 32px rgba(0,0,0,0.7);">
            <button onclick="closeAboutModal()" style="position:absolute; top:16px; right:18px; background:none; border:none; color:#e50914; font-size:28px; cursor:pointer;">&times;</button>
            <h2 style="color:#e50914; margin-bottom:12px;">About MovieStream</h2>
            <p style="font-size:16px; color:#ccc; margin-bottom:18px;">MovieStream is a school project designed to help students learn web development by building a modern movie catalog. Browse, search, and discover movies by category, rating, and more. This project demonstrates PHP, MySQL, and responsive web design best practices.</p>
            <h3 style="color:#e50914; margin-bottom:8px; font-size:18px;">Our Team</h3>
            <ul style="color:#b3b3b3; font-size:15px; margin-bottom:0; padding-left:18px;">
                <li>Developer: <strong>Justin Joshua Toledo</strong></li>
                <li>Course: <strong>BSIT</strong></li>
            </ul>
        </div>
    </div>

    <script>
    function openAboutModal(e) {
        if(e) e.preventDefault();
        document.getElementById('aboutModal').style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }
    function closeAboutModal() {
        document.getElementById('aboutModal').style.display = 'none';
        document.body.style.overflow = '';
    }
    // Optional: Close modal on background click
    document.addEventListener('DOMContentLoaded', function() {
        var modal = document.getElementById('aboutModal');
        if(modal) {
            modal.addEventListener('click', function(e) {
                if(e.target === modal) closeAboutModal();
            });
        }
    });
    </script>
</body>
</html>

<?php mysqli_close($conn); ?>
