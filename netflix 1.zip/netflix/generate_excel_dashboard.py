import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.chart import BarChart, Reference
from openpyxl.worksheet.table import Table, TableStyleInfo

# Create workbook and sheets
template = openpyxl.Workbook()
ws_movies = template.active
ws_movies.title = "Movies"
ws_users = template.create_sheet("Users")
ws_dashboard = template.create_sheet("Dashboard")

# Movies sheet headers and style
movies_headers = ["Movie ID", "Title", "Genre", "Release Year", "Rating"]
ws_movies.append(movies_headers)
for col in range(1, len(movies_headers)+1):
    ws_movies.cell(row=1, column=col).font = Font(bold=True, color="FFFFFF")
    ws_movies.cell(row=1, column=col).fill = PatternFill(start_color="4F81BD", fill_type="solid")
    ws_movies.cell(row=1, column=col).alignment = Alignment(horizontal="center")

# Users sheet headers and style
users_headers = ["User ID", "Username", "Email", "Registration Date"]
ws_users.append(users_headers)
for col in range(1, len(users_headers)+1):
    ws_users.cell(row=1, column=col).font = Font(bold=True, color="FFFFFF")
    ws_users.cell(row=1, column=col).fill = PatternFill(start_color="9BBB59", fill_type="solid")
    ws_users.cell(row=1, column=col).alignment = Alignment(horizontal="center")

# Add sample data
ws_movies.append([1, "Inception", "Sci-Fi", 2010, 8.8])
ws_movies.append([2, "The Matrix", "Action", 1999, 8.7])
ws_users.append([1, "john_doe", "john@example.com", "2024-01-10"])
ws_users.append([2, "jane_smith", "jane@example.com", "2024-02-14"])

# Create tables
tab_movies = Table(displayName="MoviesTable", ref="A1:E3")
tab_users = Table(displayName="UsersTable", ref="A1:D3")
tab_style = TableStyleInfo(name="TableStyleMedium9", showRowStripes=True)
tab_movies.tableStyleInfo = tab_style
tab_users.tableStyleInfo = tab_style
ws_movies.add_table(tab_movies)
ws_users.add_table(tab_users)

# Dashboard: Movie count, User count
ws_dashboard["A1"] = "Dashboard"
ws_dashboard["A1"].font = Font(size=16, bold=True)
ws_dashboard["A3"] = "Total Movies:"
ws_dashboard["B3"] = "=COUNTA(Movies!A:A)-1"
ws_dashboard["A4"] = "Total Users:"
ws_dashboard["B4"] = "=COUNTA(Users!A:A)-1"

# Chart: Movies by Genre
ws_dashboard["A6"] = "Movies by Genre"
genre_count = {}
for row in ws_movies.iter_rows(min_row=2, max_row=ws_movies.max_row, min_col=3, max_col=3, values_only=True):
    genre = row[0]
    if genre:
        genre_count[genre] = genre_count.get(genre, 0) + 1
ws_dashboard.append(["Genre", "Count"])
for genre, count in genre_count.items():
    ws_dashboard.append([genre, count])
chart = BarChart()
chart.title = "Movies by Genre"
chart.x_axis.title = "Genre"
chart.y_axis.title = "Count"
data = Reference(ws_dashboard, min_col=2, min_row=8, max_row=8+len(genre_count)-1)
cats = Reference(ws_dashboard, min_col=1, min_row=8, max_row=8+len(genre_count)-1)
chart.add_data(data, titles_from_data=False)
chart.set_categories(cats)
ws_dashboard.add_chart(chart, "D6")

# Save template
template.save("netflix_dashboard_template.xlsx")
print("Excel dashboard created: netflix_dashboard_template.xlsx")
