<?php
/**
 * Movie Catalog - Main Page
 * ==========================
 * Displays movies grouped by category in horizontal scrolling rows
 */

// Start session to check login status
session_start();

// Include database connection
require_once 'db.php';

// Get search query if exists
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

// Get featured movie (highest rated movie for hero banner)
$featured_sql = "SELECT m.*, GROUP_CONCAT(c.name SEPARATOR ', ') as categories
                 FROM movies m 
                 LEFT JOIN movie_category mc ON m.id = mc.movie_id
                 LEFT JOIN categories c ON mc.category_id = c.id
                 GROUP BY m.id
                 ORDER BY m.rating DESC 
                 LIMIT 1";
$featured_result = mysqli_query($conn, $featured_sql);
$featured_movie = mysqli_fetch_assoc($featured_result);

// Get trending movies (recent with high ratings)
$trending_sql = "SELECT DISTINCT m.* 
                 FROM movies m 
                 WHERE m.year >= 2022 AND m.rating >= 7.5
                 ORDER BY m.rating DESC, m.year DESC 
                 LIMIT 10";
$trending_result = mysqli_query($conn, $trending_sql);

// Get top 10 movies
$top10_sql = "SELECT DISTINCT m.* 
              FROM movies m 
              ORDER BY m.rating DESC 
              LIMIT 10";
$top10_result = mysqli_query($conn, $top10_sql);

// Get all categories
$categories_sql = "SELECT * FROM categories ORDER BY name";
$categories_result = mysqli_query($conn, $categories_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MovieStream - Your Movie Catalog</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Header Section -->
    <header class="header">
        <div class="container">
            <div class="nav-wrapper">
                <!-- Logo -->
                <div class="logo">
                    <h1>🎬 MovieStream</h1>
                </div>
                
                <!-- Navigation Menu -->
                <nav class="nav-menu">
                    <a href="index.php" class="nav-link active">Home</a>
                    <a href="categories.php" class="nav-link">Categories</a>
                    <a href="favorites.php" class="nav-link">Favorites</a>
                    <a href="#" class="nav-link" onclick="openAboutModal(event)">About us</a>
                </nav>
                
                <!-- User Account Section -->
                <div class="user-account">
                    <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
                        <span class="welcome-user">👤 <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                        <a href="logout.php" class="logout-link">Logout</a>
                    <?php else: ?>
                        <a href="login.php" class="login-link">Sign In</a>
                    <?php endif; ?>
                </div>
                
                <!-- Search Box -->
                <div class="header-search">
                    <form method="GET" action="search.php" class="search-form-header">
                        <input 
                            type="text" 
                            name="search" 
                            placeholder="Search movies..." 
                            value="<?php echo htmlspecialchars($search); ?>"
                            class="search-input-header"
                        >
                        <button type="submit" class="search-btn-header">🔍</button>
                    </form>
                </div>
            </div>
        </div>
    </header>

    <?php if (empty($search)): ?>
        <!-- Netflix-Style Hero Banner with Featured Movie -->
        <section class="hero-banner" style="background: linear-gradient(to right, rgba(0,0,0,0.8) 40%, rgba(0,0,0,0.3) 70%, transparent), url('<?php echo htmlspecialchars($featured_movie['image_url']); ?>'); background-size: cover; background-position: center;">
            <div class="hero-overlay">
                <div class="container">
                    <div class="hero-content">
                        <div class="hero-badge">
                            <span class="featured-badge">Featured</span>
                            <span class="rating-badge">⭐ <?php echo $featured_movie['rating']; ?></span>
                        </div>
                        <h1 class="hero-title"><?php echo htmlspecialchars($featured_movie['title']); ?></h1>
                        <div class="hero-meta">
                            <span><?php echo $featured_movie['year']; ?></span>
                            <span class="meta-separator">•</span>
                            <span><?php echo floor($featured_movie['duration'] / 60); ?>h <?php echo $featured_movie['duration'] % 60; ?>m</span>
                            <span class="meta-separator">•</span>
                            <span><?php echo htmlspecialchars($featured_movie['categories']); ?></span>
                        </div>
                        <p class="hero-description">
                            <?php 
                            $desc = $featured_movie['description'];
                            echo htmlspecialchars(strlen($desc) > 200 ? substr($desc, 0, 200) . '...' : $desc);
                            ?>
                        </p>
                        <div class="hero-buttons">
                            <button class="hero-btn play-btn" onclick="window.location.href='movie.php?id=<?php echo $featured_movie['id']; ?>'">
                                Play
                            </button>
                            <button class="hero-btn info-btn" onclick="window.location.href='movie.php?id=<?php echo $featured_movie['id']; ?>'">
                                More Info
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Trending Now Section -->
        <?php if (mysqli_num_rows($trending_result) > 0): ?>
        <section class="movies-section">
            <div class="category-row">
                <div class="container">
                    <h2 class="category-title">
                        <span class="trending-icon">🔥</span> Trending Now
                    </h2>
                    
                    <div class="movies-row-wrapper">
                        <button class="scroll-btn scroll-left" onclick="scrollRow(this, 'left')">‹</button>
                        
                        <div class="movies-row">
                            <?php
                            $trend_index = 1;
                            mysqli_data_seek($trending_result, 0);
                            while ($movie = mysqli_fetch_assoc($trending_result)):
                            ?>
                                <div class="movie-card-horizontal trending-card" onclick="window.location.href='movie.php?id=<?php echo $movie['id']; ?>'">
                                    <div class="trending-rank"><?php echo $trend_index++; ?></div>
                                    <div class="movie-poster-horizontal">
                                        <img src="<?php echo htmlspecialchars($movie['image_url']); ?>" 
                                             alt="<?php echo htmlspecialchars($movie['title']); ?>">
                                        <div class="movie-overlay-horizontal">
                                            <div class="movie-rating-horizontal">⭐ <?php echo $movie['rating']; ?></div>
                                            <div class="movie-play-icon">▶</div>
                                        </div>
                                    </div>
                                    <div class="movie-info-horizontal">
                                        <h3 class="movie-title-horizontal"><?php echo htmlspecialchars($movie['title']); ?></h3>
                                        <div class="movie-meta-horizontal">
                                            <span><?php echo $movie['year']; ?></span>
                                            <span><?php echo $movie['duration']; ?> min</span>
                                        </div>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        </div>
                        
                        <button class="scroll-btn scroll-right" onclick="scrollRow(this, 'right')">›</button>
                    </div>
                </div>
            </div>
        </section>
        <?php endif; ?>

        <!-- Top 10 Movies Section -->
        <?php if (mysqli_num_rows($top10_result) > 0): ?>
        <section class="movies-section">
            <div class="category-row">
                <div class="container">
                    <h2 class="category-title">
                        <span class="top10-icon">🏆</span> Top 10 Movies
                    </h2>
                    
                    <div class="movies-row-wrapper">
                        <button class="scroll-btn scroll-left" onclick="scrollRow(this, 'left')">‹</button>
                        
                        <div class="movies-row">
                            <?php
                            $top_index = 1;
                            mysqli_data_seek($top10_result, 0);
                            while ($movie = mysqli_fetch_assoc($top10_result)):
                            ?>
                                <div class="movie-card-horizontal top10-card" onclick="window.location.href='movie.php?id=<?php echo $movie['id']; ?>'">
                                    <div class="top10-number"><?php echo $top_index++; ?></div>
                                    <div class="movie-poster-horizontal">
                                        <img src="<?php echo htmlspecialchars($movie['image_url']); ?>" 
                                             alt="<?php echo htmlspecialchars($movie['title']); ?>">
                                        <div class="movie-overlay-horizontal">
                                            <div class="movie-rating-horizontal">⭐ <?php echo $movie['rating']; ?></div>
                                            <div class="movie-play-icon">▶</div>
                                        </div>
                                    </div>
                                    <div class="movie-info-horizontal">
                                        <h3 class="movie-title-horizontal"><?php echo htmlspecialchars($movie['title']); ?></h3>
                                        <div class="movie-meta-horizontal">
                                            <span><?php echo $movie['year']; ?></span>
                                            <span><?php echo $movie['duration']; ?> min</span>
                                        </div>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        </div>
                        
                        <button class="scroll-btn scroll-right" onclick="scrollRow(this, 'right')">›</button>
                    </div>
                </div>
            </div>
        </section>
        <?php endif; ?>

        <!-- Movies by Category Section -->
        <section class="movies-section">
            <?php
            // Reset categories result pointer
            mysqli_data_seek($categories_result, 0);
            
            // Loop through each category
            while ($category = mysqli_fetch_assoc($categories_result)) {
                $category_id = $category['id'];
                $category_name = $category['name'];
                
                // Get movies for this category
                $movies_sql = "SELECT DISTINCT m.* 
                               FROM movies m 
                               JOIN movie_category mc ON m.id = mc.movie_id 
                               WHERE mc.category_id = $category_id 
                               ORDER BY m.rating DESC";
                $movies_result = mysqli_query($conn, $movies_sql);
                
                // Only display category if it has movies
                if (mysqli_num_rows($movies_result) > 0) {
            ?>
                <div class="category-row">
                    <div class="container">
                        <h2 class="category-title"><?php echo htmlspecialchars($category_name); ?></h2>
                        
                        <div class="movies-row-wrapper">
                            <!-- Scroll Left Button -->
                            <button class="scroll-btn scroll-left" onclick="scrollRow(this, 'left')">‹</button>
                            
                            <!-- Movies Row -->
                            <div class="movies-row">
                                <?php
                                // Loop through movies in this category
                                while ($movie = mysqli_fetch_assoc($movies_result)) {
                                    // Get all categories for this movie
                                    $cat_sql = "SELECT c.name FROM categories c 
                                                JOIN movie_category mc ON c.id = mc.category_id 
                                                WHERE mc.movie_id = {$movie['id']}";
                                    $cat_result = mysqli_query($conn, $cat_sql);
                                    $categories = [];
                                    while ($cat = mysqli_fetch_assoc($cat_result)) {
                                        $categories[] = $cat['name'];
                                    }
                                    $category_display = !empty($categories) ? implode(', ', $categories) : 'Uncategorized';
                                ?>
                                    <div class="movie-card-horizontal" onclick="window.location.href='movie.php?id=<?php echo $movie['id']; ?>'">
                                        <!-- Movie Poster -->
                                        <div class="movie-poster-horizontal">
                                            <img src="<?php echo htmlspecialchars($movie['image_url']); ?>" 
                                                 alt="<?php echo htmlspecialchars($movie['title']); ?>">
                                            <div class="movie-overlay-horizontal">
                                                <div class="movie-rating-horizontal">⭐ <?php echo $movie['rating']; ?></div>
                                                <div class="movie-play-icon">▶</div>
                                            </div>
                                        </div>
                                        
                                        <!-- Movie Info (Shown on Hover) -->
                                        <div class="movie-info-horizontal">
                                            <h3 class="movie-title-horizontal"><?php echo htmlspecialchars($movie['title']); ?></h3>
                                            <div class="movie-meta-horizontal">
                                                <span><?php echo $movie['year']; ?></span>
                                                <span><?php echo $movie['duration']; ?> min</span>
                                            </div>
                                            <p class="movie-description-horizontal">
                                                <?php 
                                                $description = $movie['description'];
                                                echo htmlspecialchars(strlen($description) > 100 ? substr($description, 0, 100) . '...' : $description);
                                                ?>
                                            </p>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>
                            
                            <!-- Scroll Right Button -->
                            <button class="scroll-btn scroll-right" onclick="scrollRow(this, 'right')">›</button>
                        </div>
                    </div>
                </div>
            <?php
                }
            }
            ?>
        </section>

    <?php else: ?>
        <!-- Search Results Section -->
        <section class="search-results-section">
            <div class="container">
                <h2 class="search-results-title">Search Results for "<?php echo htmlspecialchars($search); ?>"</h2>
                
                <?php
                // Search query
                $search_sql = "SELECT DISTINCT m.* FROM movies m 
                               WHERE m.title LIKE '%$search%' OR m.description LIKE '%$search%'
                               ORDER BY m.rating DESC";
                $search_result = mysqli_query($conn, $search_sql);
                
                if (mysqli_num_rows($search_result) > 0) {
                    echo '<div class="movies-grid">';
                    
                    while ($movie = mysqli_fetch_assoc($search_result)) {
                        // Get categories
                        $cat_sql = "SELECT c.name FROM categories c 
                                    JOIN movie_category mc ON c.id = mc.category_id 
                                    WHERE mc.movie_id = {$movie['id']}";
                        $cat_result = mysqli_query($conn, $cat_sql);
                        $categories = [];
                        while ($cat = mysqli_fetch_assoc($cat_result)) {
                            $categories[] = $cat['name'];
                        }
                        $category_display = !empty($categories) ? implode(', ', $categories) : 'Uncategorized';
                ?>
                    <div class="movie-card" onclick="window.location.href='movie.php?id=<?php echo $movie['id']; ?>'">
                        <div class="movie-poster">
                            <img src="<?php echo htmlspecialchars($movie['image_url']); ?>" 
                                 alt="<?php echo htmlspecialchars($movie['title']); ?>">
                            <div class="movie-overlay">
                                <div class="movie-rating">⭐ <?php echo $movie['rating']; ?>/10</div>
                            </div>
                        </div>
                        <div class="movie-info">
                            <h3 class="movie-title"><?php echo htmlspecialchars($movie['title']); ?></h3>
                            <div class="movie-meta">
                                <span class="movie-year"><?php echo $movie['year']; ?></span>
                                <span class="movie-duration"><?php echo $movie['duration']; ?> min</span>
                                <span class="movie-category"><?php echo htmlspecialchars($category_display); ?></span>
                            </div>
                            <p class="movie-description">
                                <?php 
                                $description = $movie['description'];
                                echo htmlspecialchars(strlen($description) > 120 ? substr($description, 0, 120) . '...' : $description);
                                ?>
                            </p>
                            <button class="watch-btn" onclick="event.stopPropagation(); window.location.href='movie.php?id=<?php echo $movie['id']; ?>'">
                                ▶ Watch Now
                            </button>
                        </div>
                    </div>
                <?php
                    }
                    echo '</div>';
                } else {
                    echo '<div class="no-results">';
                    echo '<h3>No movies found</h3>';
                    echo '<p>Try searching with different keywords</p>';
                    echo '<a href="index.php" class="back-btn">← Back to Home</a>';
                    echo '</div>';
                }
                ?>
            </div>
        </section>
    <?php endif; ?>

    <!-- Footer Section -->
    <footer class="footer" style="background: linear-gradient(135deg, #181818 0%, #1a1a1a 100%); color: #b3b3b3; padding: 40px 0 0 0; margin-top: 60px; border-top: 1px solid #222;">
        <div class="container">
            <div class="footer-content" style="display: flex; flex-wrap: wrap; justify-content: space-between; gap: 40px;">
                <div class="footer-section" style="flex: 1 1 220px; min-width: 200px;">
                    <h4 style="color: #e50914; font-size: 24px; margin-bottom: 10px;">🎬 MovieStream</h4>
                    <p style="color: #ccc;">Your ultimate movie catalog for school projects.<br>Enjoy browsing and discovering new favorites!</p>
                    
                </div>
                <div class="footer-section" style="flex: 1 1 180px; min-width: 160px;">
                    <h4 style="color: #e50914; font-size: 18px; margin-bottom: 10px;">Quick Links</h4>
                    <ul style="list-style: none; padding: 0; margin: 0;">
                        <li><a href="index.php" style="color: #b3b3b3; text-decoration: none;">Home</a></li>
                        <li><a href="categories.php" style="color: #b3b3b3; text-decoration: none;">Categories</a></li>
                        <li><a href="favorites.php" style="color: #b3b3b3; text-decoration: none;">Favorites</a></li>
                        <li><a href="#" style="color: #b3b3b3; text-decoration: none;" onclick="openAboutModal(event)">About</a></li>
                    </ul>
                </div>
                <div class="footer-section" style="flex: 1 1 180px; min-width: 160px;">
                    <h4 style="color: #e50914; font-size: 18px; margin-bottom: 10px;">Status</h4>
                    <p style="margin: 0 0 8px 0;">Total Movies: <?php 
                        $count_sql = "SELECT COUNT(*) as total FROM movies";
                        $count_result = mysqli_query($conn, $count_sql);
                        $count = mysqli_fetch_assoc($count_result);
                        echo $count['total'];
                    ?></p>
                    <p style="margin: 0;">Categories: <?php 
                        $cat_count_sql = "SELECT COUNT(*) as total FROM categories";
                        $cat_count_result = mysqli_query($conn, $cat_count_sql);
                        $cat_count = mysqli_fetch_assoc($cat_count_result);
                        echo $cat_count['total'];
                    ?></p>
                </div>
            </div>
            <div class="footer-bottom" style="text-align: center; margin-top: 32px; padding: 18px 0 0 0; border-top: 1px solid #222; color: #666; font-size: 15px;">
                <p>Submitted by Justin Joshua Toledo</p>
            </div>
        </div>
    </footer>

    <!-- JavaScript -->
    <!-- About Us Modal -->
    <div id="aboutModal" style="display:none; position:fixed; z-index:9999; left:0; top:0; width:100vw; height:100vh; background:rgba(0,0,0,0.7); align-items:center; justify-content:center;">
        <div style="background:#181818; color:#fff; border-radius:12px; max-width:500px; width:90vw; margin:auto; padding:36px 28px 28px 28px; position:relative; box-shadow:0 8px 32px rgba(0,0,0,0.7);">
            <button onclick="closeAboutModal()" style="position:absolute; top:16px; right:18px; background:none; border:none; color:#e50914; font-size:28px; cursor:pointer;">&times;</button>
            <h2 style="color:#e50914; margin-bottom:12px;">About MovieStream</h2>
            <p style="font-size:16px; color:#ccc; margin-bottom:18px;">MovieStream is a school project designed to help students learn web development by building a modern movie catalog. Browse, search, and discover movies by category, rating, and more. This project demonstrates PHP, MySQL, and responsive web design best practices.</p>
            <h3 style="color:#e50914; margin-bottom:8px; font-size:18px;">Our Team</h3>
            <ul style="color:#b3b3b3; font-size:15px; margin-bottom:0; padding-left:18px;">
                <li>Lead Developer: <strong>Your Name</strong></li>
                <li>UI/UX Designer: <strong>Teammate Name</strong></li>
                <li>Database &amp; Backend: <strong>Teammate Name</strong></li>
                <li>Special Thanks: <strong>Instructor Name</strong></li>
            </ul>
        </div>
    </div>

    <script>
    function openAboutModal(e) {
        if(e) e.preventDefault();
        document.getElementById('aboutModal').style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }
    function closeAboutModal() {
        document.getElementById('aboutModal').style.display = 'none';
        document.body.style.overflow = '';
    }
    // Optional: Close modal on background click
    document.addEventListener('DOMContentLoaded', function() {
        var modal = document.getElementById('aboutModal');
        if(modal) {
            modal.addEventListener('click', function(e) {
                if(e.target === modal) closeAboutModal();
            });
        }
    });
    </script>
    <script src="script.js"></script>
</body>
</html>

<?php
// Close database connection
mysqli_close($conn);
?>
