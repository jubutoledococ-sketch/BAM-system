<?php
/**
 * Login Page
 * ==========
 * Simple login system using PHP sessions
 * For school project - no password hashing
 */

// Start session at the beginning
session_start();

// If user is already logged in, redirect to homepage
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    header('Location: index.php');
    exit();
}

// Initialize variables
$error = '';
$success = '';

// Check if user just logged out
if (isset($_GET['logout']) && $_GET['logout'] === 'success') {
    $success = 'You have been successfully logged out';
}

// Process login form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    require_once 'db.php';
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';

    if (empty($username) || empty($password)) {
        $error = 'Please enter both username and password';
    } else {
        // Demo users (hardcoded)
        $valid_users = [
            'admin' => 'admin123',
            'user' => 'user123',
            'student' => 'student123'
        ];
        if (array_key_exists($username, $valid_users) && $valid_users[$username] === $password) {
            $_SESSION['logged_in'] = true;
            $_SESSION['username'] = $username;
            unset($_SESSION['user_id']);
            $_SESSION['login_time'] = time();
            header('Location: index.php');
            exit();
        }

        // Check database for registered users
        $stmt = $conn->prepare('SELECT id, username, password FROM users WHERE username = ? OR email = ? LIMIT 1');
        $stmt->bind_param('ss', $username, $username);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            if ($password === $row['password']) {
                $_SESSION['logged_in'] = true;
                $_SESSION['username'] = $row['username'];
                $_SESSION['user_id'] = (int)$row['id'];
                $_SESSION['login_time'] = time();
                header('Location: index.php');
                exit();
            } else {
                $error = 'Invalid username or password';
            }
        } else {
            $error = 'Invalid username or password';
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - MovieStream</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* Additional styles for login page */
        .login-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            background: linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%);
        }

        .login-box {
            background: linear-gradient(145deg, #1a1a1a 0%, #0f0f0f 100%);
            border-radius: 12px;
            padding: 40px;
            max-width: 450px;
            width: 100%;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.6);
            border: 1px solid rgba(229, 9, 20, 0.2);
        }

        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .login-logo {
            font-size: 36px;
            color: #e50914;
            font-weight: bold;
            margin-bottom: 10px;
            background: linear-gradient(135deg, #e50914 0%, #ff1a1a 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .login-subtitle {
            color: #b3b3b3;
            font-size: 14px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            color: #e5e5e5;
            font-size: 14px;
            margin-bottom: 8px;
            font-weight: 500;
        }

        .form-input {
            width: 100%;
            padding: 14px 16px;
            background-color: rgba(255, 255, 255, 0.05);
            border: 2px solid rgba(255, 255, 255, 0.1);
            border-radius: 6px;
            color: #ffffff;
            font-size: 16px;
            transition: all 0.3s ease;
        }

        .form-input:focus {
            outline: none;
            border-color: #e50914;
            background-color: rgba(255, 255, 255, 0.1);
            box-shadow: 0 0 20px rgba(229, 9, 20, 0.2);
        }

        .login-btn {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #e50914 0%, #b20710 100%);
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-top: 10px;
        }

        .login-btn:hover {
            background: linear-gradient(135deg, #ff1a1a 0%, #e50914 100%);
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(229, 9, 20, 0.5);
        }

        .alert {
            padding: 12px 16px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .alert-error {
            background-color: rgba(229, 9, 20, 0.2);
            border: 1px solid rgba(229, 9, 20, 0.5);
            color: #ff6b6b;
        }

        .alert-success {
            background-color: rgba(40, 167, 69, 0.2);
            border: 1px solid rgba(40, 167, 69, 0.5);
            color: #5dd879;
        }

        .login-footer {
            text-align: center;
            margin-top: 25px;
            padding-top: 25px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        .login-footer a {
            color: #e50914;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .login-footer a:hover {
            color: #ff1a1a;
        }

        .demo-info {
            background-color: rgba(255, 255, 255, 0.05);
            padding: 15px;
            border-radius: 6px;
            margin-top: 20px;
            border-left: 3px solid #e50914;
        }

        .demo-info h4 {
            color: #e50914;
            font-size: 14px;
            margin-bottom: 8px;
        }

        .demo-info p {
            color: #b3b3b3;
            font-size: 13px;
            line-height: 1.6;
            margin: 5px 0;
        }

        @media (max-width: 480px) {
            .login-box {
                padding: 30px 20px;
            }

            .login-logo {
                font-size: 28px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <div class="login-header">
                <h1 class="login-logo">🎬 MovieStream</h1>
                <p class="login-subtitle">Sign in to continue</p>
            </div>

            <!-- Display error message if any -->
            <?php if (!empty($error)): ?>
                <div class="alert alert-error">
                    ⚠️ <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <!-- Display success message if any -->
            <?php if (!empty($success)): ?>
                <div class="alert alert-success">
                    ✓ <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <!-- Login Form -->
            <form method="POST" action="login.php">
                <div class="form-group">
                    <label for="username" class="form-label">Username</label>
                    <input 
                        type="text" 
                        id="username" 
                        name="username" 
                        class="form-input"
                        placeholder="Enter your username"
                        value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>"
                        required
                        autocomplete="username"
                    >
                </div>

                <div class="form-group">
                    <label for="password" class="form-label">Password</label>
                    <input 
                        type="password" 
                        id="password" 
                        name="password" 
                        class="form-input"
                        placeholder="Enter your password"
                        required
                        autocomplete="current-password"
                    >
                </div>

                <button type="submit" class="login-btn">
                    Sign In
                </button>
            </form>

            <!-- Register Button -->
            <form method="get" action="register.php" style="margin-top: 10px;">
                <button type="submit" class="login-btn" style="background: linear-gradient(135deg, #222 0%, #444 100%); color: #e50914;">Register</button>
            </form>

            <disv class="login-footer">
                <a href="index.php">← Back to Home</a>
            </div>
        </div>
    </div>
</body>
</html>
