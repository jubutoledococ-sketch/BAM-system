<?php
/**
 * Movie Details Page
 * ==================
 * Displays full information about a specific movie
 */

// Start session to check favorites
session_start();

// Require login to view movie details
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    $redirect_url = 'login.php?redirect=' . urlencode('movie.php?id=' . (isset($_GET['id']) ? $_GET['id'] : ''));
    header('Location: ' . $redirect_url);
    exit();
}

// Include database connection
require_once 'db.php';

// Initialize favorites in session if not exists
if (!isset($_SESSION['favorites'])) {
    $_SESSION['favorites'] = [];
}

// Get movie ID from URL parameter and validate it
$movie_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// If no valid ID provided, redirect to homepage
if ($movie_id <= 0) {
    header('Location: index.php');
    exit();
}

// Fetch movie details securely using parameterized query
$sql = "SELECT * FROM movies WHERE id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $movie_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// Check if movie exists
if (mysqli_num_rows($result) == 0) {
    header('Location: index.php');
    exit();
}

$movie = mysqli_fetch_assoc($result);

// Fetch all categories for this movie
$cat_sql = "SELECT c.name FROM categories c 
            JOIN movie_category mc ON c.id = mc.category_id 
            WHERE mc.movie_id = ?";
$cat_stmt = mysqli_prepare($conn, $cat_sql);
mysqli_stmt_bind_param($cat_stmt, "i", $movie_id);
mysqli_stmt_execute($cat_stmt);
$cat_result = mysqli_stmt_get_result($cat_stmt);

$categories = [];
while ($cat = mysqli_fetch_assoc($cat_result)) {
    $categories[] = $cat['name'];
}

// Fetch similar movies from the same categories
$similar_sql = "SELECT DISTINCT m.* FROM movies m
                JOIN movie_category mc ON m.id = mc.movie_id
                WHERE mc.category_id IN (
                    SELECT category_id FROM movie_category WHERE movie_id = ?
                )
                AND m.id != ?
                ORDER BY m.rating DESC
                LIMIT 6";
$similar_stmt = mysqli_prepare($conn, $similar_sql);
mysqli_stmt_bind_param($similar_stmt, "ii", $movie_id, $movie_id);
mysqli_stmt_execute($similar_stmt);
$similar_result = mysqli_stmt_get_result($similar_stmt);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($movie['title']); ?> - MovieStream</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* Additional styles specific to movie details page */
        .movie-detail-hero {
            background: linear-gradient(to bottom, rgba(0,0,0,0.3), rgba(20,20,20,0.95)),
                        url('<?php echo htmlspecialchars($movie['image_url']); ?>');
            background-size: cover;
            background-position: center;
            padding: 120px 0 60px;
            margin-bottom: 40px;
        }

        .back-button {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 25px;
            background-color: rgba(255, 255, 255, 0.1);
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-size: 16px;
            transition: all 0.3s ease;
            margin-bottom: 30px;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .back-button:hover {
            background-color: rgba(255, 255, 255, 0.2);
            transform: translateX(-5px);
        }

        .detail-content {
            display: grid;
            grid-template-columns: 350px 1fr;
            gap: 40px;
            margin-bottom: 60px;
        }

        .detail-poster {
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 10px 40px rgba(0,0,0,0.6);
        }

        .detail-poster img {
            width: 100%;
            height: auto;
            display: block;
        }

        .detail-info h1 {
            font-size: 42px;
            margin-bottom: 15px;
            color: #ffffff;
        }

        .detail-rating {
            display: inline-block;
            background: linear-gradient(135deg, #e50914, #b20710);
            padding: 8px 20px;
            border-radius: 25px;
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .detail-meta {
            display: flex;
            gap: 25px;
            margin-bottom: 25px;
            font-size: 16px;
            color: #b3b3b3;
            flex-wrap: wrap;
        }

        .detail-meta-item {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .detail-meta-item::before {
            content: "•";
            color: #e50914;
            font-size: 20px;
        }

        .detail-meta-item:first-child::before {
            content: "";
        }

        .detail-categories {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-bottom: 25px;
        }

        .category-tag {
            padding: 8px 18px;
            background-color: rgba(229, 9, 20, 0.15);
            border: 1px solid rgba(229, 9, 20, 0.5);
            border-radius: 20px;
            color: #ff6b6b;
            font-size: 14px;
            font-weight: 500;
        }

        .detail-description {
            font-size: 18px;
            line-height: 1.8;
            color: #e5e5e5;
            margin-bottom: 30px;
        }

        .detail-actions {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }

        .action-button {
            padding: 15px 35px;
            font-size: 18px;
            font-weight: bold;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .btn-primary {
            background-color: #e50914;
            color: white;
        }

        .btn-primary:hover {
            background-color: #b20710;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(229, 9, 20, 0.4);
        }

        .btn-secondary {
            background-color: rgba(255, 255, 255, 0.2);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        .btn-secondary:hover {
            background-color: rgba(255, 255, 255, 0.3);
            transform: translateY(-2px);
        }

        .similar-movies-section {
            margin-top: 60px;
        }

        .section-title {
            font-size: 28px;
            margin-bottom: 25px;
            color: #e5e5e5;
        }

        @media (max-width: 968px) {
            .detail-content {
                grid-template-columns: 1fr;
                gap: 30px;
            }

            .detail-poster {
                max-width: 400px;
                margin: 0 auto;
            }

            .detail-info h1 {
                font-size: 32px;
            }
        }

        @media (max-width: 480px) {
            .detail-info h1 {
                font-size: 26px;
            }

            .detail-description {
                font-size: 16px;
            }

            .action-button {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <!-- Header Section -->
    <header class="header">
        <div class="container">
            <div class="nav-wrapper">
                <!-- Logo -->
                <div class="logo">
                    <h1>🎬 MovieStream</h1>
                </div>
                
                <!-- Navigation Menu -->
                <nav class="nav-menu">
                    <a href="index.php" class="nav-link">Home</a>
                    <a href="categories.php" class="nav-link">Categories</a>
                    <a href="favorites.php" class="nav-link">Favorites</a>
                    <a href="#" class="nav-link" onclick="openAboutModal(event)">About us</a>
                </nav>
                
                <!-- Search Box -->
                <div class="header-search">
                    <form method="GET" action="search.php" class="search-form-header">
                        <input 
                            type="text" 
                            name="search" 
                            placeholder="Search movies..." 
                            class="search-input-header"
                        >
                        <button type="submit" class="search-btn-header">🔍</button>
                    </form>
                </div>
            </div>
        </div>
    </header>

    <!-- Movie Detail Hero Section -->
    <section class="movie-detail-hero">
        <div class="container">
            <a href="index.php" class="back-button">← Back to Home</a>
            
            <div class="detail-content">
                <!-- Movie Poster -->
                <div class="detail-poster">
                    <img src="<?php echo htmlspecialchars($movie['image_url']); ?>" 
                         alt="<?php echo htmlspecialchars($movie['title']); ?>">
                </div>

                <!-- Movie Information -->
                <div class="detail-info">
                    <h1><?php echo htmlspecialchars($movie['title']); ?></h1>
                    
                    <div class="detail-rating">
                        ⭐ <?php echo $movie['rating']; ?> / 10
                    </div>

                    <div class="detail-meta">
                        <span class="detail-meta-item"><?php echo $movie['year']; ?></span>
                        <span class="detail-meta-item"><?php echo $movie['duration']; ?> minutes</span>
                        <span class="detail-meta-item"><?php echo floor($movie['duration'] / 60); ?>h <?php echo $movie['duration'] % 60; ?>m</span>
                    </div>

                    <?php if (!empty($categories)): ?>
                        <div class="detail-categories">
                            <?php foreach ($categories as $category): ?>
                                <span class="category-tag"><?php echo htmlspecialchars($category); ?></span>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <p class="detail-description">
                        <?php echo htmlspecialchars($movie['description']); ?>
                    </p>

                    <div class="detail-actions">
                        <button class="action-button btn-primary" onclick="playMovie()">
                            ▶ Play Now
                        </button>
                        <button class="action-button btn-secondary" onclick="toggleFavorite()">
                            <?php echo in_array($movie_id, $_SESSION['favorites']) ? '❤️ Remove from Favorites' : '🤍 Add to Favorites'; ?>
                        </button>
                        <button class="action-button btn-secondary" onclick="shareMovie()">
                            🔗 Share
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Similar Movies Section -->
    <?php if (mysqli_num_rows($similar_result) > 0): ?>
        <section class="similar-movies-section">
            <div class="container">
                <h2 class="section-title">Similar Movies You Might Like</h2>
                
                <div class="movies-grid">
                    <?php while ($similar = mysqli_fetch_assoc($similar_result)): 
                        // Get categories for similar movie
                        $sim_cat_sql = "SELECT c.name FROM categories c 
                                        JOIN movie_category mc ON c.id = mc.category_id 
                                        WHERE mc.movie_id = {$similar['id']}";
                        $sim_cat_result = mysqli_query($conn, $sim_cat_sql);
                        $sim_categories = [];
                        while ($sim_cat = mysqli_fetch_assoc($sim_cat_result)) {
                            $sim_categories[] = $sim_cat['name'];
                        }
                        $sim_category_display = !empty($sim_categories) ? implode(', ', $sim_categories) : 'Uncategorized';
                    ?>
                        <div class="movie-card" onclick="window.location.href='movie.php?id=<?php echo $similar['id']; ?>'">
                            <div class="movie-poster">
                                <img src="<?php echo htmlspecialchars($similar['image_url']); ?>" 
                                     alt="<?php echo htmlspecialchars($similar['title']); ?>">
                                <div class="movie-overlay">
                                    <div class="movie-rating">⭐ <?php echo $similar['rating']; ?>/10</div>
                                </div>
                            </div>
                            <div class="movie-info">
                                <h3 class="movie-title"><?php echo htmlspecialchars($similar['title']); ?></h3>
                                <div class="movie-meta">
                                    <span class="movie-year"><?php echo $similar['year']; ?></span>
                                    <span class="movie-duration"><?php echo $similar['duration']; ?> min</span>
                                    <span class="movie-category"><?php echo htmlspecialchars($sim_category_display); ?></span>
                                </div>
                                <p class="movie-description">
                                    <?php 
                                    $description = $similar['description'];
                                    echo htmlspecialchars(strlen($description) > 120 ? substr($description, 0, 120) . '...' : $description);
                                    ?>
                                </p>
                                <button class="watch-btn" onclick="event.stopPropagation(); window.location.href='movie.php?id=<?php echo $similar['id']; ?>'">
                                    ▶ Watch Now
                                </button>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <!-- Footer Section -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h4>MovieStream</h4>
                    <p>Your ultimate movie catalog for school projects</p>
                </div>
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="#">Movies</a></li>
                        <li><a href="#">Categories</a></li>
                        <li><a href="#">About</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Share</h4>
                    <p>Tell your friends about this movie!</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2026 MovieStream - School Project</p>
            </div>
        </div>
    </footer>

    <script>
        async function playMovie() {
            try {
                const body = new URLSearchParams();
                body.append('movie_id', '<?php echo $movie_id; ?>');
                await fetch('play_now_log.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                    body: body.toString()
                });
            } catch (error) {
                // Keep UX smooth even if analytics logging fails.
            }
            showNotification('▶ Playing: <?php echo addslashes($movie['title']); ?>', 'success');
            // In a real application, this would start video playback
        }

        function toggleFavorite() {
            const isFavorite = <?php echo in_array($movie_id, $_SESSION['favorites']) ? 'true' : 'false'; ?>;
            const action = isFavorite ? 'remove' : 'add';
            window.location.href = 'favorites.php?action=' + action + '&id=<?php echo $movie_id; ?>';
        }

        function shareMovie() {
            // Copy URL to clipboard
            const url = window.location.href;
            navigator.clipboard.writeText(url).then(() => {
                showNotification('🔗 Link copied to clipboard!', 'info');
            }).catch(() => {
                showNotification('Share: ' + url, 'info');
            });
        }

        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.textContent = message;
            notification.style.cssText = `
                position: fixed;
                top: 80px;
                right: 20px;
                padding: 15px 25px;
                background-color: ${type === 'success' ? '#28a745' : type === 'error' ? '#e50914' : '#333'};
                color: white;
                border-radius: 4px;
                z-index: 1000;
                box-shadow: 0 4px 12px rgba(0,0,0,0.5);
                animation: slideInRight 0.3s ease;
                max-width: 300px;
            `;
            
            const style = document.createElement('style');
            style.textContent = `
                @keyframes slideInRight {
                    from { transform: translateX(400px); opacity: 0; }
                    to { transform: translateX(0); opacity: 1; }
                }
                @keyframes slideOutRight {
                    from { transform: translateX(0); opacity: 1; }
                    to { transform: translateX(400px); opacity: 0; }
                }
            `;
            document.head.appendChild(style);
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.style.animation = 'slideOutRight 0.3s ease';
                setTimeout(() => notification.remove(), 300);
            }, 3000);
        }
    </script>
        </script>
    <div id="aboutModal" style="display:none; position:fixed; z-index:9999; left:0; top:0; width:100vw; height:100vh; background:rgba(0,0,0,0.7); align-items:center; justify-content:center;">
        <div style="background:#181818; color:#fff; border-radius:12px; max-width:500px; width:90vw; margin:auto; padding:36px 28px 28px 28px; position:relative; box-shadow:0 8px 32px rgba(0,0,0,0.7);">
            <button onclick="closeAboutModal()" style="position:absolute; top:16px; right:18px; background:none; border:none; color:#e50914; font-size:28px; cursor:pointer;">&times;</button>
            <h2 style="color:#e50914; margin-bottom:12px;">About MovieStream</h2>
            <p style="font-size:16px; color:#ccc; margin-bottom:18px;">MovieStream is a school project designed to help students learn web development by building a modern movie catalog. Browse, search, and discover movies by category, rating, and more. This project demonstrates PHP, MySQL, and responsive web design best practices.</p>
            <h3 style="color:#e50914; margin-bottom:8px; font-size:18px;">Our Team</h3>
            <ul style="color:#b3b3b3; font-size:15px; margin-bottom:0; padding-left:18px;">
                <li>Developer: <strong>Justin Joshua Toledo</strong></li>
                <li>Course: <strong>BSIT</strong></li>
            </ul>
        </div>
    </div>

    <script>
    function openAboutModal(e) {
        if(e) e.preventDefault();
        document.getElementById('aboutModal').style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }
    function closeAboutModal() {
        document.getElementById('aboutModal').style.display = 'none';
        document.body.style.overflow = '';
    }
    // Optional: Close modal on background click
    document.addEventListener('DOMContentLoaded', function() {
        var modal = document.getElementById('aboutModal');
        if(modal) {
            modal.addEventListener('click', function(e) {
                if(e.target === modal) closeAboutModal();
            });
        }
    });
    </script>
</body>
</html>

<?php
// Close database connection
mysqli_close($conn);
?>
