<?php
/**
 * Logs Play Now clicks for analytics.
 */

session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'message' => 'Unauthorized']);
    exit();
}

require_once 'db.php';

$createTableSql = "CREATE TABLE IF NOT EXISTS movie_plays (
    id INT AUTO_INCREMENT PRIMARY KEY,
    movie_id INT NOT NULL,
    user_id INT NULL,
    username VARCHAR(50) NOT NULL,
    played_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_movie_plays_movie (movie_id),
    INDEX idx_movie_plays_user (user_id),
    INDEX idx_movie_plays_username (username),
    INDEX idx_movie_plays_played_at (played_at)
)";
mysqli_query($conn, $createTableSql);

$movieId = isset($_POST['movie_id']) ? (int)$_POST['movie_id'] : 0;
if ($movieId <= 0) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => 'Invalid movie id']);
    mysqli_close($conn);
    exit();
}

$username = isset($_SESSION['username']) ? trim((string)$_SESSION['username']) : '';
$sessionUserId = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0;
$userId = $sessionUserId > 0 ? $sessionUserId : null;

if ($username === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => 'Missing username']);
    mysqli_close($conn);
    exit();
}

if ($userId === null) {
    $lookupSql = "SELECT id FROM users WHERE username = ? LIMIT 1";
    $lookupStmt = mysqli_prepare($conn, $lookupSql);
    if ($lookupStmt) {
        mysqli_stmt_bind_param($lookupStmt, "s", $username);
        mysqli_stmt_execute($lookupStmt);
        $lookupResult = mysqli_stmt_get_result($lookupStmt);
        if ($lookupResult && ($row = mysqli_fetch_assoc($lookupResult))) {
            $userId = (int)$row['id'];
        }
        mysqli_stmt_close($lookupStmt);
    }
}

$ok = false;
if ($userId === null) {
    $insertSql = "INSERT INTO movie_plays (movie_id, user_id, username) VALUES (?, NULL, ?)";
    $stmt = mysqli_prepare($conn, $insertSql);
    if (!$stmt) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'message' => 'Prepare failed']);
        mysqli_close($conn);
        exit();
    }
    mysqli_stmt_bind_param($stmt, "is", $movieId, $username);
    $ok = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
} else {
    $insertSql = "INSERT INTO movie_plays (movie_id, user_id, username) VALUES (?, ?, ?)";
    $stmt = mysqli_prepare($conn, $insertSql);
    if (!$stmt) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'message' => 'Prepare failed']);
        mysqli_close($conn);
        exit();
    }
    mysqli_stmt_bind_param($stmt, "iis", $movieId, $userId, $username);
    $ok = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

mysqli_close($conn);

if (!$ok) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => 'Insert failed']);
    exit();
}

echo json_encode(['ok' => true]);
