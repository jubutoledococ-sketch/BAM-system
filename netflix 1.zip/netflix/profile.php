<?php
// profile.php - User profile management page
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

require_once 'db.php';

$user_id = $_SESSION['user_id'];

// Fetch user info
$stmt = $conn->prepare('SELECT username, email FROM users WHERE id = ?');
$stmt->bind_param('i', $user_id);
$stmt->execute();
$stmt->bind_result($username, $email);
$stmt->fetch();
$stmt->close();

// Handle messages
$success = isset($_GET['success']) ? $_GET['success'] : '';
$error = isset($_GET['error']) ? $_GET['error'] : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Profile Settings</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Profile Settings</h2>
    <?php if ($success): ?>
        <div class="success-msg"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="error-msg"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <div class="profile-section">
        <h3>Account Info</h3>
        <p><strong>Username:</strong> <?= htmlspecialchars($username) ?></p>
        <p><strong>Email:</strong> <?= htmlspecialchars($email) ?></p>
    </div>
    <div class="profile-section">
        <h3>Change Password</h3>
        <form action="profile_change_password.php" method="post">
            <label>Current Password: <input type="password" name="current_password" required></label><br>
            <label>New Password: <input type="password" name="new_password" required></label><br>
            <label>Confirm New Password: <input type="password" name="confirm_password" required></label><br>
            <button type="submit">Change Password</button>
        </form>
    </div>
    <div class="profile-section">
        <h3>Payment Method</h3>
        <form action="profile_payment.php" method="post">
            <label>Card Number: <input type="text" name="card_number" maxlength="19" required></label><br>
            <label>Expiry Date: <input type="text" name="expiry" placeholder="MM/YY" required></label><br>
            <label>CVV: <input type="password" name="cvv" maxlength="4" required></label><br>
            <button type="submit">Update Payment</button>
        </form>
    </div>
    <a href="index.php">Back to Home</a>
</body>
</html>
