$ErrorActionPreference = 'Stop'

$projectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$mysqlExe = 'C:\xampp\mysql\bin\mysql.exe'
$dbName = 'movie_catalog'
$outPath = Join-Path $projectDir 'netflix_dashboard_live.xlsx'

function Get-MySqlRows([string]$query) {
    & $mysqlExe -u root -D $dbName --batch --raw -e $query
}

Get-MySqlRows "CREATE TABLE IF NOT EXISTS movie_plays (id INT AUTO_INCREMENT PRIMARY KEY, movie_id INT NOT NULL, user_id INT NULL, username VARCHAR(50) NOT NULL, played_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE, FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL, INDEX idx_movie_plays_movie (movie_id), INDEX idx_movie_plays_user (user_id), INDEX idx_movie_plays_username (username), INDEX idx_movie_plays_played_at (played_at));" | Out-Null

$dataRows = Get-MySqlRows "SELECT m.id AS movie_id, m.title AS movie_title, COALESCE(u.id, mp.user_id) AS user_id, COALESCE(u.username, mp.username) AS username, u.email, ROUND(m.duration/60,2) AS hours_per_movie, mp.played_at FROM movie_plays mp JOIN movies m ON m.id = mp.movie_id LEFT JOIN users u ON u.id = mp.user_id ORDER BY mp.played_at DESC, m.title, username;"
$movieSummaryRows = Get-MySqlRows "SELECT m.title AS movie_title, COUNT(mp.id) AS play_count, ROUND(COALESCE(SUM(m.duration),0)/60,2) AS total_hours FROM movies m LEFT JOIN movie_plays mp ON mp.movie_id = m.id GROUP BY m.id, m.title ORDER BY play_count DESC, total_hours DESC, m.title;"
$userSummaryRows = Get-MySqlRows "SELECT u.username, u.email, COUNT(mp.id) AS play_count, ROUND(COALESCE(SUM(m.duration),0)/60,2) AS total_hours FROM users u LEFT JOIN movie_plays mp ON (mp.user_id = u.id OR (mp.user_id IS NULL AND mp.username = u.username)) LEFT JOIN movies m ON m.id = mp.movie_id GROUP BY u.id, u.username, u.email ORDER BY play_count DESC, total_hours DESC, u.username;"

$excel = New-Object -ComObject Excel.Application
$excel.Visible = $false
$excel.DisplayAlerts = $false

try {
    $wb = $excel.Workbooks.Add()
    while ($wb.Worksheets.Count -lt 4) { $null = $wb.Worksheets.Add() }

    $wsData = $wb.Worksheets.Item(1); $wsData.Name = 'MovieUserData'
    $wsMovie = $wb.Worksheets.Item(2); $wsMovie.Name = 'MovieSummary'
    $wsUser = $wb.Worksheets.Item(3); $wsUser.Name = 'UserSummary'
    $wsDash = $wb.Worksheets.Item(4); $wsDash.Name = 'Dashboard'

    function Write-TabDataToSheet($sheet, $rows) {
        $r = 1
        foreach ($line in $rows) {
            $cols = $line -split "`t"
            for ($c = 0; $c -lt $cols.Count; $c++) {
                $sheet.Cells.Item($r, $c + 1).Value2 = $cols[$c]
            }
            $r++
        }
        return ($r - 1)
    }

    $null = Write-TabDataToSheet $wsData $dataRows
    $movieLast = Write-TabDataToSheet $wsMovie $movieSummaryRows
    $userLast = Write-TabDataToSheet $wsUser $userSummaryRows

    foreach ($ws in @($wsData, $wsMovie, $wsUser)) {
        $used = $ws.UsedRange
        $used.Columns.AutoFit() | Out-Null
        $used.Borders.LineStyle = 1
        $used.Borders.Weight = 2
        $used.Interior.Color = 15921906
        $used.Font.Color = 0
        $header = $ws.Range($ws.Cells.Item(1, 1), $ws.Cells.Item(1, $used.Columns.Count))
        $header.Font.Bold = $true
        $header.Font.Color = 16777215
        $header.Interior.Color = 12040119
        $header.HorizontalAlignment = -4108
    }

    $wsData.Columns.Item(6).NumberFormat = '0.00'
    $wsMovie.Columns.Item(2).NumberFormat = '0'
    $wsMovie.Columns.Item(3).NumberFormat = '0.00'
    $wsUser.Columns.Item(3).NumberFormat = '0'
    $wsUser.Columns.Item(4).NumberFormat = '0.00'

    $wsDash.Range('A1').Value2 = 'Netflix Dashboard'
    $wsDash.Range('A1').Font.Size = 20
    $wsDash.Range('A1').Font.Bold = $true
    $wsDash.Range('A1').Font.Color = 16777215
    $wsDash.Range('A1:Q50').Interior.Color = 3158064
    $wsDash.Range('A1:Q50').Font.Color = 16777215
    $wsDash.Range('A1:Q1').Interior.Color = 192

    $wsDash.Range('A3').Value2 = 'Total Movies'
    $wsDash.Range('B3').Formula = '=COUNTA(MovieSummary!A:A)-1'
    $wsDash.Range('A4').Value2 = 'Total Users'
    $wsDash.Range('B4').Formula = '=COUNTA(UserSummary!A:A)-1'
    $wsDash.Range('A5').Value2 = 'Total Connected Rows'
    $wsDash.Range('B5').Formula = '=COUNTA(MovieUserData!A:A)-1'
    $wsDash.Range('A6').Value2 = 'Total Play Clicks'
    $wsDash.Range('B6').Formula = '=SUM(MovieSummary!B:B)'
    $wsDash.Range('A7').Value2 = 'Total Watch Hours (From Plays)'
    $wsDash.Range('B7').Formula = '=SUM(MovieSummary!C:C)'
    $wsDash.Range('B6').NumberFormat = '0'
    $wsDash.Range('B7').NumberFormat = '0.00'

    $kpiRange = $wsDash.Range('A3:B7')
    $kpiRange.Font.Bold = $true
    $kpiRange.Borders.LineStyle = 1
    $kpiRange.Interior.Color = 755384
    $wsDash.Columns.Item('A:B').AutoFit() | Out-Null
    $wsDash.Range('A3:A7').Interior.Color = 12040119

    $topN = [Math]::Min(11, $movieLast)
    $chartObj1 = $wsDash.ChartObjects().Add(20, 230, 620, 300)
    $chart1 = $chartObj1.Chart
    $chart1.ChartType = 57
    $chart1.SetSourceData($wsMovie.Range("B2:B$topN"))
    $chart1.SeriesCollection(1).XValues = $wsMovie.Range("A2:A$topN")
    $chart1.HasTitle = $true
    $chart1.ChartTitle.Text = 'Top Movies by Play Count'
    $chart1.ChartArea.Interior.Color = 16777215
    $chart1.PlotArea.Interior.Color = 16777215

    $chartObj2 = $wsDash.ChartObjects().Add(670, 230, 560, 300)
    $chart2 = $chartObj2.Chart
    $chart2.ChartType = 5
    $chart2.SetSourceData($wsUser.Range("C2:C$userLast"))
    $chart2.SeriesCollection(1).XValues = $wsUser.Range("A2:A$userLast")
    $chart2.HasTitle = $true
    $chart2.ChartTitle.Text = 'Play Count by User'
    $chart2.ChartArea.Interior.Color = 16777215
    $chart2.PlotArea.Interior.Color = 16777215

    # Top 10 movies analysis table
    $top10 = [Math]::Min(10, $movieLast - 1)
    $wsDash.Range('A9:F9').Merge()
    $wsDash.Range('A9').Value2 = 'Top 10 Movies in the System'
    $wsDash.Range('A9:F9').Font.Bold = $true
    $wsDash.Range('A9:F9').Interior.Color = 12040119
    $wsDash.Range('A10').Value2 = 'Rank'
    $wsDash.Range('B10').Value2 = 'Movie'
    $wsDash.Range('C10').Value2 = 'Play Count'
    $wsDash.Range('D10').Value2 = 'Total Hours'
    $wsDash.Range('E10:F10').Merge()
    $wsDash.Range('E10').Value2 = 'Status'
    $wsDash.Range('A10:F10').Font.Bold = $true
    $wsDash.Range('A10:F10').Interior.Color = 755384

    for ($i = 0; $i -lt $top10; $i++) {
        $dashRow = 11 + $i
        $sourceRow = 2 + $i
        $wsDash.Cells.Item($dashRow, 1).Value2 = [string]($i + 1)
        $wsDash.Cells.Item($dashRow, 2).Formula = "=MovieSummary!A$sourceRow"
        $wsDash.Cells.Item($dashRow, 3).Formula = "=MovieSummary!B$sourceRow"
        $wsDash.Cells.Item($dashRow, 4).Formula = "=MovieSummary!C$sourceRow"
        $wsDash.Range("E$dashRow:F$dashRow").Merge()
        if ($i -eq 0) {
            $wsDash.Range("E$dashRow").Value2 = 'Most played movie'
        } else {
            $wsDash.Range("E$dashRow").Value2 = 'Top 10'
        }
    }

    $tableEnd = 10 + $top10
    $wsDash.Range("C11:C$tableEnd").NumberFormat = '0'
    $wsDash.Range("D11:D$tableEnd").NumberFormat = '0.00'
    $wsDash.Range("A11:F$tableEnd").Interior.Color = 15921906
    $wsDash.Range("A10:F$tableEnd").Borders.LineStyle = 1
    $wsDash.Columns.Item('A:F').AutoFit() | Out-Null

    $xlOpenXMLWorkbook = 51
    try {
        $wb.SaveAs($outPath, $xlOpenXMLWorkbook)
    } catch {
        # If the main workbook is open/locked, write to a fallback file instead.
        $fallbackPath = Join-Path $projectDir 'netflix_dashboard_live_latest.xlsx'
        $wb.SaveAs($fallbackPath, $xlOpenXMLWorkbook)
    }
    $wb.Close($true)
} finally {
    $excel.Quit()
}
