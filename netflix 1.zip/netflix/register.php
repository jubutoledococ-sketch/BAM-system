<?php
/**
 * Register Page
 * =============
 * Simple registration system for school project
 * No password hashing, for demonstration only
 */


session_start();
require_once 'db.php';

// If user is already logged in, redirect to homepage
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    header('Location: index.php');
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
    $confirm = isset($_POST['confirm']) ? trim($_POST['confirm']) : '';

    if (empty($username) || empty($email) || empty($password) || empty($confirm)) {
        $error = 'Please fill in all fields';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email address';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match';
    } else {
        // Check if username or email already exists
        $stmt = $conn->prepare('SELECT id FROM users WHERE username = ? OR email = ?');
        $stmt->bind_param('ss', $username, $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $error = 'Username or email already exists';
        } else {
            // Store password as plain text (not secure, for demo only)
            $stmt = $conn->prepare('INSERT INTO users (username, email, password) VALUES (?, ?, ?)');
            $stmt->bind_param('sss', $username, $email, $password);
            if ($stmt->execute()) {
                // Rebuild Excel dashboard automatically after each successful signup.
                $script_path = __DIR__ . DIRECTORY_SEPARATOR . 'rebuild_excel_dashboard.ps1';
                if (file_exists($script_path)) {
                    $ps_cmd = 'powershell -NoProfile -ExecutionPolicy Bypass -File ' . escapeshellarg($script_path) . ' >NUL 2>&1';
                    @pclose(@popen($ps_cmd, 'r'));
                }
                $success = 'Registration successful! You can now log in.';
            } else {
                $error = 'Registration failed. Please try again.';
            }
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - MovieStream</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .login-container { min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px; background: linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 100%); }
        .login-box { background: linear-gradient(145deg, #1a1a1a 0%, #0f0f0f 100%); border-radius: 12px; padding: 40px; max-width: 450px; width: 100%; box-shadow: 0 8px 32px rgba(0, 0, 0, 0.6); border: 1px solid rgba(229, 9, 20, 0.2); }
        .login-header { text-align: center; margin-bottom: 30px; }
        .login-logo { font-size: 36px; color: #e50914; font-weight: bold; margin-bottom: 10px; background: linear-gradient(135deg, #e50914 0%, #ff1a1a 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
        .login-subtitle { color: #b3b3b3; font-size: 14px; }
        .form-group { margin-bottom: 20px; }
        .form-label { display: block; color: #e5e5e5; font-size: 14px; margin-bottom: 8px; font-weight: 500; }
        .form-input { width: 100%; padding: 14px 16px; background-color: rgba(255, 255, 255, 0.05); border: 2px solid rgba(255, 255, 255, 0.1); border-radius: 6px; color: #ffffff; font-size: 16px; transition: all 0.3s ease; }
        .form-input:focus { outline: none; border-color: #e50914; background-color: rgba(255, 255, 255, 0.1); box-shadow: 0 0 20px rgba(229, 9, 20, 0.2); }
        .login-btn { width: 100%; padding: 16px; background: linear-gradient(135deg, #e50914 0%, #b20710 100%); color: white; border: none; border-radius: 6px; font-size: 16px; font-weight: bold; cursor: pointer; transition: all 0.3s ease; text-transform: uppercase; letter-spacing: 1px; margin-top: 10px; }
        .login-btn:hover { background: linear-gradient(135deg, #ff1a1a 0%, #e50914 100%); transform: translateY(-2px); box-shadow: 0 6px 20px rgba(229, 9, 20, 0.5); }
        .alert { padding: 12px 16px; border-radius: 6px; margin-bottom: 20px; font-size: 14px; }
        .alert-error { background-color: rgba(229, 9, 20, 0.2); border: 1px solid rgba(229, 9, 20, 0.5); color: #ff6b6b; }
        .alert-success { background-color: rgba(40, 167, 69, 0.2); border: 1px solid rgba(40, 167, 69, 0.5); color: #5dd879; }
        .login-footer { text-align: center; margin-top: 25px; padding-top: 25px; border-top: 1px solid rgba(255, 255, 255, 0.1); }
        .login-footer a { color: #e50914; text-decoration: none; font-weight: 500; transition: color 0.3s ease; }
        .login-footer a:hover { color: #ff1a1a; }
        @media (max-width: 480px) { .login-box { padding: 30px 20px; } .login-logo { font-size: 28px; } }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <div class="login-header">
                <h1 class="login-logo">🎬 MovieStream</h1>
                <p class="login-subtitle">Create your account</p>
            </div>
            <?php if (!empty($error)): ?>
                <div class="alert alert-error">
                    ⚠️ <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            <?php if (!empty($success)): ?>
                <div class="alert alert-success">
                    ✓ <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>
            <form method="POST" action="register.php">
                <div class="form-group">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" id="username" name="username" class="form-input" placeholder="Choose a username" value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>" required autocomplete="username">
                </div>
                <div class="form-group">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" id="email" name="email" class="form-input" placeholder="Enter your email" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" required autocomplete="email">
                </div>
                <div class="form-group">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" id="password" name="password" class="form-input" placeholder="Create a password" required autocomplete="new-password">
                </div>
                <div class="form-group">
                    <label for="confirm" class="form-label">Confirm Password</label>
                    <input type="password" id="confirm" name="confirm" class="form-input" placeholder="Confirm your password" required autocomplete="new-password">
                </div>
                <button type="submit" class="login-btn">Register</button>
            </form>
            <div class="login-footer">
                <a href="login.php">Already have an account? Sign In</a>
            </div>
        </div>
    </div>
</body>
</html>
