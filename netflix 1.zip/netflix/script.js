/**
 * Movie Catalog - JavaScript
 * ===========================
 * Interactive features for horizontal scrolling movie catalog
 */

// Wait for the page to fully load before running scripts
document.addEventListener('DOMContentLoaded', function() {
    // Initialize the application
    init();
});

/**
 * Initialize the application
 * Sets up event listeners and initial state
 */
function init() {
    console.log('MovieStream app initialized!');
    
    // Add smooth scroll behavior
    addSmoothScroll();
    
    // Add keyboard shortcut for search (Ctrl + K or Cmd + K)
    addSearchShortcut();
    
    // Initialize horizontal scroll with mouse wheel
    initializeHorizontalScroll();
}

/**
 * Scroll a movie row left or right
 * @param {HTMLElement} button - The scroll button that was clicked
 * @param {string} direction - 'left' or 'right'
 */
function scrollRow(button, direction) {
    // Find the movies row container
    const wrapper = button.parentElement;
    const moviesRow = wrapper.querySelector('.movies-row');
    
    // Calculate scroll amount (about 3 cards worth)
    const scrollAmount = 900;
    
    // Scroll in the specified direction
    if (direction === 'left') {
        moviesRow.scrollBy({
            left: -scrollAmount,
            behavior: 'smooth'
        });
    } else {
        moviesRow.scrollBy({
            left: scrollAmount,
            behavior: 'smooth'
        });
    }
}

/**
 * Enable horizontal scrolling with mouse wheel/trackpad
 */
function initializeHorizontalScroll() {
    const movieRows = document.querySelectorAll('.movies-row');
    
    movieRows.forEach(row => {
        row.addEventListener('wheel', function(e) {
            // Prevent default vertical scrolling
            if (Math.abs(e.deltaX) < Math.abs(e.deltaY)) {
                e.preventDefault();
                // Convert vertical scroll to horizontal
                this.scrollLeft += e.deltaY;
            }
        }, { passive: false });
    });
}

/**
 * Show movie details (legacy function - now redirects to movie.php)
 * This function is called when clicking on a movie card
 * @param {number} movieId - The ID of the movie
 */
function showMovieDetails(movieId) {
    // Redirect to movie details page
    window.location.href = 'movie.php?id=' + movieId;
}

/**
 * Add smooth scrolling to all anchor links
 */
function addSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

/**
 * Add keyboard shortcut for quick access to search
 * Press Ctrl+K (Windows) or Cmd+K (Mac) to focus search input
 */
function addSearchShortcut() {
    document.addEventListener('keydown', function(e) {
        // Check for Ctrl+K or Cmd+K
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
            e.preventDefault();
            
            // Focus the search input
            const searchInput = document.querySelector('.search-input-header');
            if (searchInput) {
                searchInput.focus();
                searchInput.select();
            }
        }
        
        // Press Escape to clear search
        if (e.key === 'Escape') {
            const searchInput = document.querySelector('.search-input-header');
            if (searchInput && document.activeElement === searchInput) {
                searchInput.blur();
            }
        }
    });
}

/**
 * Add scroll effect to header
 * Makes header more compact when scrolling down
 */
let lastScroll = 0;
window.addEventListener('scroll', function() {
    const header = document.querySelector('.header');
    const currentScroll = window.scrollY;
    
    if (currentScroll > 50) {
        header.style.padding = '10px 0';
    } else {
        header.style.padding = '20px 0';
    }
    
    lastScroll = currentScroll;
});

/**
 * Show notification message
 * Useful for showing feedback to users
 * @param {string} message - The message to display
 * @param {string} type - Type of notification ('success', 'error', 'info')
 */
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 80px;
        right: 20px;
        padding: 15px 25px;
        background-color: ${type === 'success' ? '#28a745' : type === 'error' ? '#e50914' : '#333'};
        color: white;
        border-radius: 4px;
        z-index: 1000;
        box-shadow: 0 4px 12px rgba(0,0,0,0.5);
        animation: slideInRight 0.3s ease;
        max-width: 300px;
    `;
    
    // Add CSS animation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideInRight {
            from {
                transform: translateX(400px);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        @keyframes slideOutRight {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(400px);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);
    
    document.body.appendChild(notification);
    
    // Remove notification after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Log that the script has loaded
console.log('MovieStream JavaScript loaded successfully!');
