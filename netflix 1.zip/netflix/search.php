<?php
/**
 * Advanced Search Page
 * ====================
 * Search with filters for year, rating, duration, and categories
 */

session_start();
require_once 'db.php';

// Get search parameters
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$category = isset($_GET['category']) ? (int)$_GET['category'] : 0;
$year_min = isset($_GET['year_min']) ? (int)$_GET['year_min'] : 0;
$year_max = isset($_GET['year_max']) ? (int)$_GET['year_max'] : date('Y');
$rating_min = isset($_GET['rating_min']) ? (float)$_GET['rating_min'] : 0;
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'rating_desc';

// Build query
$where_clauses = [];
$params = [];
$types = '';

if (!empty($search)) {
    $where_clauses[] = "(m.title LIKE ? OR m.description LIKE ?)";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
    $types .= 'ss';
}

if ($category > 0) {
    $where_clauses[] = "mc.category_id = ?";
    $params[] = $category;
    $types .= 'i';
}

if ($year_min > 0) {
    $where_clauses[] = "m.year >= ?";
    $params[] = $year_min;
    $types .= 'i';
}

if ($year_max > 0) {
    $where_clauses[] = "m.year <= ?";
    $params[] = $year_max;
    $types .= 'i';
}

if ($rating_min > 0) {
    $where_clauses[] = "m.rating >= ?";
    $params[] = $rating_min;
    $types .= 'd';
}

// Sort options
$sort_sql = match($sort) {
    'title_asc' => 'ORDER BY m.title ASC',
    'title_desc' => 'ORDER BY m.title DESC',
    'year_asc' => 'ORDER BY m.year ASC',
    'year_desc' => 'ORDER BY m.year DESC',
    'rating_asc' => 'ORDER BY m.rating ASC',
    'duration_asc' => 'ORDER BY m.duration ASC',
    'duration_desc' => 'ORDER BY m.duration DESC',
    default => 'ORDER BY m.rating DESC'
};

// Build final query
$where_sql = !empty($where_clauses) ? 'WHERE ' . implode(' AND ', $where_clauses) : '';

$sql = "SELECT DISTINCT m.* 
        FROM movies m 
        LEFT JOIN movie_category mc ON m.id = mc.movie_id 
        $where_sql 
        $sort_sql";

if (!empty($params)) {
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, $types, ...$params);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
} else {
    $result = mysqli_query($conn, $sql);
}

// Get all categories for filter
$categories_sql = "SELECT * FROM categories ORDER BY name";
$categories_result = mysqli_query($conn, $categories_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Advanced Search - MovieStream</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .search-page {
            padding: 100px 0 60px;
            min-height: 100vh;
        }
        
        .search-filters {
            background: linear-gradient(145deg, #1a1a1a 0%, #0f0f0f 100%);
            border-radius: 12px;
            padding: 30px;
            margin-bottom: 40px;
            border: 1px solid rgba(255, 255, 255, 0.05);
        }
        
        .filter-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .filter-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        
        .filter-label {
            color: #b3b3b3;
            font-size: 14px;
            font-weight: 500;
        }
        
        .filter-input,
        .filter-select {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: #ffffff;
            padding: 12px 15px;
            border-radius: 6px;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        
        .filter-input:focus,
        .filter-select:focus {
            outline: none;
            border-color: #e50914;
            background: rgba(255, 255, 255, 0.08);
        }
        
        .filter-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
        }
        
        .filter-btn {
            padding: 12px 30px;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .btn-search {
            background: linear-gradient(135deg, #e50914, #b20710);
            color: white;
        }
        
        .btn-search:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(229, 9, 20, 0.4);
        }
        
        .btn-reset {
            background: rgba(255, 255, 255, 0.1);
            color: #ffffff;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .btn-reset:hover {
            background: rgba(255, 255, 255, 0.2);
        }
        
        .results-info {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding: 20px;
            background: rgba(255, 255, 255, 0.03);
            border-radius: 8px;
        }
        
        .results-count {
            font-size: 18px;
            color: #ffffff;
        }
        
        .results-sort {
            display: flex;
            align-items: center;
            gap: 10px;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="nav-wrapper">
                <div class="logo">
                    <h1>🎬 MovieStream</h1>
                </div>
                <nav class="nav-menu">
                    <a href="index.php" class="nav-link">Home</a>
                    <a href="categories.php" class="nav-link">Categories</a>
                    <a href="favorites.php" class="nav-link">Favorites</a>
                    <a href="search.php" class="nav-link active">Search</a>
                </nav>
                <div class="user-account">
                    <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
                        <span class="welcome-user">👤 <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                        <a href="logout.php" class="logout-link">Logout</a>
                    <?php else: ?>
                        <a href="login.php" class="login-link">Sign In</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <section class="search-page">
        <div class="container">
            <h1 class="page-title" style="font-size: 42px; margin-bottom: 30px;">🔍 Advanced Search</h1>

            <!-- Search Filters -->
            <form method="GET" action="search.php" class="search-filters">
                <div class="filter-row">
                    <div class="filter-group">
                        <label class="filter-label">Search Keywords</label>
                        <input type="text" name="search" class="filter-input" 
                               placeholder="Movie title or description..."
                               value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    
                    <div class="filter-group">
                        <label class="filter-label">Category</label>
                        <select name="category" class="filter-select">
                            <option value="0">All Categories</option>
                            <?php 
                            mysqli_data_seek($categories_result, 0);
                            while ($cat = mysqli_fetch_assoc($categories_result)): 
                            ?>
                                <option value="<?php echo $cat['id']; ?>" 
                                        <?php echo $category == $cat['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($cat['name']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label class="filter-label">Min Rating</label>
                        <select name="rating_min" class="filter-select">
                            <option value="0">Any Rating</option>
                            <?php for ($i = 9; $i >= 5; $i--): ?>
                                <option value="<?php echo $i; ?>" <?php echo $rating_min == $i ? 'selected' : ''; ?>>
                                    <?php echo $i; ?>+ Stars
                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                </div>
                
                <div class="filter-row">
                    <div class="filter-group">
                        <label class="filter-label">Year From</label>
                        <input type="number" name="year_min" class="filter-input" 
                               placeholder="e.g. 2020" min="1900" max="<?php echo date('Y'); ?>"
                               value="<?php echo $year_min > 0 ? $year_min : ''; ?>">
                    </div>
                    
                    <div class="filter-group">
                        <label class="filter-label">Year To</label>
                        <input type="number" name="year_max" class="filter-input" 
                               placeholder="e.g. 2024" min="1900" max="<?php echo date('Y'); ?>"
                               value="<?php echo $year_max != date('Y') ? $year_max : ''; ?>">
                    </div>
                    
                    <div class="filter-group">
                        <label class="filter-label">Sort By</label>
                        <select name="sort" class="filter-select">
                            <option value="rating_desc" <?php echo $sort == 'rating_desc' ? 'selected' : ''; ?>>Rating (High to Low)</option>
                            <option value="rating_asc" <?php echo $sort == 'rating_asc' ? 'selected' : ''; ?>>Rating (Low to High)</option>
                            <option value="year_desc" <?php echo $sort == 'year_desc' ? 'selected' : ''; ?>>Year (Newest)</option>
                            <option value="year_asc" <?php echo $sort == 'year_asc' ? 'selected' : ''; ?>>Year (Oldest)</option>
                            <option value="title_asc" <?php echo $sort == 'title_asc' ? 'selected' : ''; ?>>Title (A-Z)</option>
                            <option value="title_desc" <?php echo $sort == 'title_desc' ? 'selected' : ''; ?>>Title (Z-A)</option>
                            <option value="duration_desc" <?php echo $sort == 'duration_desc' ? 'selected' : ''; ?>>Duration (Longest)</option>
                            <option value="duration_asc" <?php echo $sort == 'duration_asc' ? 'selected' : ''; ?>>Duration (Shortest)</option>
                        </select>
                    </div>
                </div>
                
                <div class="filter-actions">
                    <button type="button" class="filter-btn btn-reset" onclick="window.location.href='search.php'">
                        Clear Filters
                    </button>
                    <button type="submit" class="filter-btn btn-search">
                        🔍 Search Movies
                    </button>
                </div>
            </form>

            <!-- Results -->
            <?php
            $movie_count = mysqli_num_rows($result);
            ?>
            
            <div class="results-info">
                <div class="results-count">
                    Found <strong><?php echo $movie_count; ?></strong> movies
                </div>
            </div>

            <?php if ($movie_count > 0): ?>
                <div class="movies-grid">
                    <?php while ($movie = mysqli_fetch_assoc($result)): ?>
                        <div class="movie-card" onclick="window.location.href='movie.php?id=<?php echo $movie['id']; ?>'">
                            <div class="movie-poster">
                                <img src="<?php echo htmlspecialchars($movie['image_url']); ?>" 
                                     alt="<?php echo htmlspecialchars($movie['title']); ?>">
                                <div class="movie-overlay">
                                    <div class="movie-rating">⭐ <?php echo $movie['rating']; ?>/10</div>
                                </div>
                            </div>
                            <div class="movie-info">
                                <h3 class="movie-title"><?php echo htmlspecialchars($movie['title']); ?></h3>
                                <div class="movie-meta">
                                    <span class="movie-year"><?php echo $movie['year']; ?></span>
                                    <span class="movie-duration"><?php echo $movie['duration']; ?> min</span>
                                </div>
                                <p class="movie-description">
                                    <?php 
                                    $desc = $movie['description'];
                                    echo htmlspecialchars(strlen($desc) > 100 ? substr($desc, 0, 100) . '...' : $desc);
                                    ?>
                                </p>
                                <button class="watch-btn" onclick="event.stopPropagation(); window.location.href='movie.php?id=<?php echo $movie['id']; ?>'">
                                    ▶ Watch Now
                                </button>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div class="no-results" style="text-align: center; padding: 60px 20px;">
                    <h3 style="font-size: 28px; color: #ffffff; margin-bottom: 15px;">No movies found</h3>
                    <p style="font-size: 16px; color: #b3b3b3; margin-bottom: 25px;">
                        Try adjusting your search filters or browse all movies
                    </p>
                    <a href="index.php" class="browse-btn" style="display: inline-block; background: linear-gradient(135deg, #e50914, #b20710); color: white; padding: 15px 35px; border-radius: 6px; text-decoration: none; font-weight: bold;">
                        Browse All Movies
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <script src="script.js"></script>
</body>
</html>

<?php mysqli_close($conn); ?>
