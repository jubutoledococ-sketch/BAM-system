-- ============================================
-- Update Movie Images Script
-- Run this in phpMyAdmin to update all movie images
-- ============================================

USE movie_catalog;

-- Update images for all movies
UPDATE movies SET image_url = 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=300&h=450&fit=crop' WHERE id = 1;
UPDATE movies SET image_url = 'https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=300&h=450&fit=crop' WHERE id = 2;
UPDATE movies SET image_url = 'https://images.unsplash.com/photo-1485846234645-a62644f84728?w=300&h=450&fit=crop' WHERE id = 3;
UPDATE movies SET image_url = 'https://images.unsplash.com/photo-1509248961158-e54f6934749c?w=300&h=450&fit=crop' WHERE id = 4;
UPDATE movies SET image_url = 'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=300&h=450&fit=crop' WHERE id = 5;
UPDATE movies SET image_url = 'https://images.unsplash.com/photo-1518199266791-5375a83190b7?w=300&h=450&fit=crop' WHERE id = 6;
UPDATE movies SET image_url = 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=300&h=450&fit=crop' WHERE id = 7;
UPDATE movies SET image_url = 'https://images.unsplash.com/photo-1518173946687-a4c8892bbd9f?w=300&h=450&fit=crop' WHERE id = 8;
UPDATE movies SET image_url = 'https://images.unsplash.com/photo-1542282088-fe8426682b8f?w=300&h=450&fit=crop' WHERE id = 9;
UPDATE movies SET image_url = 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=300&h=450&fit=crop' WHERE id = 10;
UPDATE movies SET image_url = 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=300&h=450&fit=crop' WHERE id = 11;
UPDATE movies SET image_url = 'https://images.unsplash.com/photo-1509822929063-6b6cfc9b42f2?w=300&h=450&fit=crop' WHERE id = 12;
UPDATE movies SET image_url = 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=300&h=450&fit=crop' WHERE id = 13;
UPDATE movies SET image_url = 'https://images.unsplash.com/photo-1464207687429-7505649dae38?w=300&h=450&fit=crop' WHERE id = 14;
UPDATE movies SET image_url = 'https://images.unsplash.com/photo-1485846234645-a62644f84728?w=300&h=450&fit=crop' WHERE id = 15;
UPDATE movies SET image_url = 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=300&h=450&fit=crop' WHERE id = 16;

-- Verify the changes
SELECT id, title, image_url FROM movies;
